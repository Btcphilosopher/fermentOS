import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import { GoogleGenAI } from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();

// Initialize Gemini Client
const apiKey = process.env['GEMINI_API_KEY'] || '';
const ai = new GoogleGenAI({
  apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

/**
 * GIN FOUNDRY REST API Endpoints
 */

// Health check endpoint
app.get('/api/v1/health', (req, res) => {
  res.json({ status: 'ONLINE', system: 'GIN FOUNDRY Digital Twin Engine v1.0', timestamp: new Date().toISOString() });
});

// AI Assistant endpoint
app.post('/api/v1/ai/assistant', async (req, res) => {
  try {
    const { prompt, stateContext } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const systemInstruction = `You are the GIN FOUNDRY AI Digital Twin Assistant, an expert distilling engineer, master blender, financial analyst, and spirits supply chain strategist.
You have direct real-time access to the company digital twin state provided below.

INSTRUCTIONS:
1. Always cite exact internal records (Batch IDs, Botanical Lot Numbers, COGS numbers, Equipment status, Flavour scores).
2. Distinguish clearly between: [OBSERVED DATA], [MODEL OUTPUT], [ASSUMPTION], and [SCENARIO].
3. Give precise, actionable advice on recipe optimization, costing bottlenecks, still capacity limits, and scale-up economics.
4. Keep answers crisp, authoritative, professional, and directly rooted in the company numbers.

CURRENT DIGITAL TWIN STATE CONTEXT:
${JSON.stringify(stateContext, null, 2)}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    const answer = response.text || 'No response generated.';
    return res.json({ answer });
  } catch (err: unknown) {
    const errorMessage = err instanceof Error ? err.message : String(err);
    console.error('AI Assistant API Error:', err);
    return res.status(500).json({ error: 'AI Assistant processing failed', details: errorMessage });
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
