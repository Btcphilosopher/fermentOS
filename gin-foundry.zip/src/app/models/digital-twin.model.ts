export interface Botanical {
  id: string;
  commonName: string;
  latinName: string;
  origin: string;
  supplier: string;
  country: string;
  harvestPeriod: string;
  organicStatus: boolean;
  pricePerKg: number; // in GBP £
  moisturePercent: number;
  typicalFlavourNotes: string[];
  aromaCompounds: string[];
  intensityScore: number; // 1 - 10
  extractionIndex: number; // 0.1 - 2.0 multiplier
  recommendedDosageRange: { minGramsPerLitre: number; maxGramsPerLitre: number };
  shelfLifeDays: number;
  leadTimeDays: number;
  supplierReliabilityPercent: number;
  carbonFootprintKgPerKg: number;
  category: 'core' | 'citrus' | 'floral' | 'herbal' | 'spice' | 'earthy' | 'custom';
}

export interface BotanicalLot {
  lotNumber: string;
  botanicalId: string;
  botanicalName: string;
  supplier: string;
  quantityKg: number;
  reservedKg: number;
  availableKg: number;
  costPerKg: number;
  receivedDate: string;
  expiryDate: string;
  qualityStatus: 'PASSED' | 'PENDING' | 'REJECTED';
  moistureContent: number;
}

export interface RecipeBotanicalDosage {
  botanicalId: string;
  botanicalName: string;
  gramsPerLitreBaseSpirit: number;
  macerationHours: number;
}

export interface RecipeVersion {
  version: string; // e.g. "v1.0"
  label: string; // e.g. "Commercial Standard"
  createdAt: string;
  author: string;
  notes: string;
  baseSpiritType: string;
  baseSpiritABV: number;
  baseSpiritVolumeL: number;
  botanicals: RecipeBotanicalDosage[];
  distillationMethod: 'POT_STILL' | 'COLUMN_HYBRID' | 'VAPOUR_INFUSION';
  macerationTempC: number;
  targetHeatskW: number;
  headsCutPercent: number; // e.g. 2%
  tailsCutPercent: number; // e.g. 15%
  heartsABV: number; // e.g. 78%
  restingDays: number;
  targetABV: number; // e.g. 43%
  filtrationType: 'CHILL_FILTERED' | 'UNFILTERED_CELLULOSE' | 'CHARCOAL';
  status: 'EXPERIMENTAL' | 'PILOT' | 'PRODUCTION' | 'ARCHIVED';
}

export interface FlavourProfile {
  juniper: number;
  citrus: number;
  floral: number;
  spice: number;
  herbal: number;
  earthy: number;
  woody: number;
  sweet: number;
  bitter: number;
  fresh: number;
  resinous: number;
  mineral: number;
}

export interface ProductSpecification {
  id: string;
  name: string;
  brand: string;
  commercialCategory: string; // e.g., "Scottish Highland Dry Gin"
  legalClassification: string; // e.g., "Distilled Gin (EU/UK Regulation)"
  abvPercent: number;
  bottleVolumeMl: number;
  targetRetailPriceGbp: number;
  targetWholesalePriceGbp: number;
  targetGrossMarginPercent: number;
  originRegion: string;
  botanicalPhilosophy: string;
  flavourDirection: string;
  activeRecipeVersion: string;
  recipeHistory: RecipeVersion[];
  flavourProfile: FlavourProfile;
  imageUrl?: string;
}

export interface PackagingSpecification {
  bottleType: string;
  bottleWeightGrams: number;
  bottleUnitCostGbp: number;
  bottleSupplier: string;
  closureType: string;
  closureUnitCostGbp: number;
  labelType: string;
  labelUnitCostGbp: number;
  cartonSizeBottles: number;
  cartonUnitCostGbp: number;
  palletCapacityCases: number;
  freightCostPerPalletGbp: number;
  recyclabilityPercent: number;
}

export interface EquipmentAsset {
  id: string;
  name: string;
  type: 'STILL' | 'BOILER' | 'CONDENSER' | 'SPIRIT_TANK' | 'WATER_SYSTEM' | 'BOTTLING_LINE' | 'WAREHOUSE';
  capacityLitre: number;
  status: 'RUNNING' | 'IDLE' | 'WAITING' | 'MAINTENANCE' | 'FAULT';
  temperatureC: number;
  pressureBar: number;
  powerKw: number;
  currentBatchId?: string;
  healthPercent: number;
  runHours: number;
  maintenanceDueDays: number;
  capexValueGbp: number;
}

export interface ProductionBatch {
  id: string;
  batchNumber: string; // e.g. "2026-0048"
  productName: string;
  recipeVersion: string;
  scheduledDate: string;
  completedDate?: string;
  status: 'PLANNED' | 'MACERATING' | 'DISTILLING' | 'QC_HOLD' | 'DILUTING' | 'BOTTLING' | 'COMPLETED';
  baseSpiritVolumeL: number;
  rawMaterialsCostGbp: number;
  energyCostGbp: number;
  labourCostGbp: number;
  packagingCostGbp: number;
  overheadCostGbp: number;
  totalBatchCostGbp: number;
  expectedBottles: number;
  actualBottlesProduced: number;
  costPerBottleGbp: number;
  assignedStillId: string;
  botanicalLotNumbers: { botanicalName: string; lotNumber: string; kgUsed: number }[];
  qcStatus: 'PASSED' | 'PENDING' | 'HOLD' | 'REJECTED';
}

export interface QualityControlRecord {
  id: string;
  batchId: string;
  batchNumber: string;
  measuredABV: number;
  measuredDensityGcm3: number;
  clarityScore: number; // 1-10
  colour: string;
  sensoryScoreOverall: number; // 1-10
  operatorName: string;
  inspectionDate: string;
  status: 'PASS' | 'HOLD' | 'RELEASE' | 'REJECT';
  notes: string;
}

export interface SensoryPanelScore {
  sampleName: string; // e.g. "Sample A (R1.04)"
  panelistName: string;
  nose: number;
  juniper: number;
  citrus: number;
  floral: number;
  herbal: number;
  spice: number;
  texture: number;
  alcoholIntegration: number;
  balance: number;
  finish: number;
  overallScore: number;
}

export interface CustomerOrder {
  id: string;
  orderNumber: string;
  customerName: string;
  customerType: 'RETAIL' | 'WHOLESALE' | 'RESTAURANT_BAR' | 'HOTEL' | 'ONLINE' | 'EXPORT_DISTRIBUTOR';
  productName: string;
  quantityCases: number;
  bottlesCount: number;
  unitPriceGbp: number;
  totalRevenueGbp: number;
  orderDate: string;
  status: 'QUOTED' | 'CONFIRMED' | 'ALLOCATED' | 'DISPATCHED' | 'DELIVERED';
  allocatedBatchId?: string;
}

export interface FinancialKPIs {
  companyValuationGbp: number;
  cashBalanceGbp: number;
  monthlyRevenueGbp: number;
  monthlyCogsGbp: number;
  grossMarginPercent: number;
  bottlesProducedYtd: number;
  bottlesSoldYtd: number;
  currentInventoryBottles: number;
  annualProductionCapacityBottles: number;
  capacityUtilisationPercent: number;
  costPerBottleGbp: number;
  avgRetailPriceGbp: number;
  avgWholesalePriceGbp: number;
  contributionMarginGbp: number;
  runwayMonths: number;
  ebitdaGbp: number;
}

export interface CompanyState {
  companyName: string;
  foundingYear: number;
  location: string;
  initialCapitalGbp: number;
  product: ProductSpecification;
  botanicals: Botanical[];
  botanicalLots: BotanicalLot[];
  packaging: PackagingSpecification;
  equipment: EquipmentAsset[];
  batches: ProductionBatch[];
  qcRecords: QualityControlRecord[];
  sensoryScores: SensoryPanelScore[];
  orders: CustomerOrder[];
  financials: FinancialKPIs;
  sustainability: {
    energyKwhPerBottle: number;
    waterLitresPerBottle: number;
    glassMassKgPerBottle: number;
    transportDistanceKm: number;
    carbonFootprintKgCo2ePerBottle: number;
  };
}

export interface TwinScenario {
  id: string;
  name: string;
  description: string;
  state: CompanyState;
  createdAt: string;
}

export interface EventLogItem {
  id: string;
  timestamp: string;
  eventType: string;
  description: string;
  impactSummary: string;
}
