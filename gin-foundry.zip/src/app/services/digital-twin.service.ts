import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import {
  Botanical,
  BotanicalLot,
  CompanyState,
  CustomerOrder,
  EquipmentAsset,
  EventLogItem,
  FlavourProfile,
  PackagingSpecification,
  ProductSpecification,
  ProductionBatch,
  QualityControlRecord,
  SensoryPanelScore,
  TwinScenario,
} from '../models/digital-twin.model';

@Injectable({
  providedIn: 'root',
})
export class DigitalTwinService {
  // Pre-seeded Botanical Library
  private readonly defaultBotanicals: Botanical[] = [
    {
      id: 'bot-juniper',
      commonName: 'Juniper Berries',
      latinName: 'Juniperus communis',
      origin: 'Highlands, Scotland',
      supplier: 'Caledonian Botanicals Ltd',
      country: 'United Kingdom',
      harvestPeriod: 'September - November',
      organicStatus: true,
      pricePerKg: 18.5,
      moisturePercent: 12.0,
      typicalFlavourNotes: ['Pine', 'Resin', 'Citrus', 'Woody'],
      aromaCompounds: ['alpha-pinene', 'myrcene', 'sabinene'],
      intensityScore: 9,
      extractionIndex: 1.2,
      recommendedDosageRange: { minGramsPerLitre: 15, maxGramsPerLitre: 45 },
      shelfLifeDays: 365,
      leadTimeDays: 14,
      supplierReliabilityPercent: 98,
      carbonFootprintKgPerKg: 0.8,
      category: 'core',
    },
    {
      id: 'bot-heather',
      commonName: 'Wild Heather Bloom',
      latinName: 'Calluna vulgaris',
      origin: 'Cairngorms National Park',
      supplier: 'Highland Foragers Co',
      country: 'United Kingdom',
      harvestPeriod: 'August - September',
      organicStatus: true,
      pricePerKg: 42.0,
      moisturePercent: 8.5,
      typicalFlavourNotes: ['Floral', 'Honey', 'Herbal', 'Sweet'],
      aromaCompounds: ['linalool', 'geraniol'],
      intensityScore: 7,
      extractionIndex: 0.9,
      recommendedDosageRange: { minGramsPerLitre: 2, maxGramsPerLitre: 10 },
      shelfLifeDays: 180,
      leadTimeDays: 21,
      supplierReliabilityPercent: 92,
      carbonFootprintKgPerKg: 0.4,
      category: 'floral',
    },
    {
      id: 'bot-seabuckthorn',
      commonName: 'Sea Buckthorn',
      latinName: 'Hippophae rhamnoides',
      origin: 'East Lothian Coast',
      supplier: 'North Sea Organics',
      country: 'United Kingdom',
      harvestPeriod: 'October - December',
      organicStatus: true,
      pricePerKg: 38.0,
      moisturePercent: 15.0,
      typicalFlavourNotes: ['Tart Citrus', 'Fresh', 'Passionate Fruit', 'Earthy'],
      aromaCompounds: ['ascorbic acid', 'citral'],
      intensityScore: 8,
      extractionIndex: 1.1,
      recommendedDosageRange: { minGramsPerLitre: 3, maxGramsPerLitre: 12 },
      shelfLifeDays: 240,
      leadTimeDays: 10,
      supplierReliabilityPercent: 95,
      carbonFootprintKgPerKg: 0.6,
      category: 'citrus',
    },
    {
      id: 'bot-coriander',
      commonName: 'Coriander Seed',
      latinName: 'Coriandrum sativum',
      origin: 'Hampshire',
      supplier: 'English Spice Merchants',
      country: 'United Kingdom',
      harvestPeriod: 'July - August',
      organicStatus: false,
      pricePerKg: 12.0,
      moisturePercent: 9.0,
      typicalFlavourNotes: ['Citrus', 'Spice', 'Woody', 'Nutty'],
      aromaCompounds: ['linalool', 'terpinene'],
      intensityScore: 7,
      extractionIndex: 1.0,
      recommendedDosageRange: { minGramsPerLitre: 8, maxGramsPerLitre: 20 },
      shelfLifeDays: 540,
      leadTimeDays: 7,
      supplierReliabilityPercent: 99,
      carbonFootprintKgPerKg: 1.1,
      category: 'spice',
    },
    {
      id: 'bot-angelica',
      commonName: 'Angelica Root',
      latinName: 'Angelica archangelica',
      origin: 'Fife',
      supplier: 'Scottish Root & Herb',
      country: 'United Kingdom',
      harvestPeriod: 'October - November',
      organicStatus: true,
      pricePerKg: 34.0,
      moisturePercent: 10.0,
      typicalFlavourNotes: ['Earthy', 'Musky', 'Herbal', 'Woody'],
      aromaCompounds: ['phellandrene', 'angelicin'],
      intensityScore: 8,
      extractionIndex: 1.0,
      recommendedDosageRange: { minGramsPerLitre: 1, maxGramsPerLitre: 5 },
      shelfLifeDays: 730,
      leadTimeDays: 14,
      supplierReliabilityPercent: 96,
      carbonFootprintKgPerKg: 0.9,
      category: 'earthy',
    },
    {
      id: 'bot-lemon',
      commonName: 'Fresh Lemon Peel',
      latinName: 'Citrus limon',
      origin: 'Amalfi Coast',
      supplier: 'Mediterranean Citrus Co',
      country: 'Italy',
      harvestPeriod: 'All Year',
      organicStatus: true,
      pricePerKg: 16.0,
      moisturePercent: 22.0,
      typicalFlavourNotes: ['Citrus', 'Fresh', 'Zesty', 'Bright'],
      aromaCompounds: ['limonene', 'citral'],
      intensityScore: 8,
      extractionIndex: 1.3,
      recommendedDosageRange: { minGramsPerLitre: 4, maxGramsPerLitre: 15 },
      shelfLifeDays: 30,
      leadTimeDays: 5,
      supplierReliabilityPercent: 97,
      carbonFootprintKgPerKg: 1.4,
      category: 'citrus',
    },
  ];

  // Default Flagship Product
  private readonly defaultProduct: ProductSpecification = {
    id: 'prod-north-atlantic',
    name: 'NORTH ATLANTIC DRY GIN',
    brand: 'NORTH ATLANTIC SPIRITS',
    commercialCategory: 'Scottish Highland Dry Gin',
    legalClassification: 'Distilled Gin (UK HMRC / EU Reg 2019/787)',
    abvPercent: 43.0,
    bottleVolumeMl: 700,
    targetRetailPriceGbp: 42.0,
    targetWholesalePriceGbp: 24.5,
    targetGrossMarginPercent: 68.5,
    originRegion: 'Highlands & Coastal Scotland',
    botanicalPhilosophy:
      'Hand-foraged coastal heather and sea buckthorn balanced with crisp Caledonian juniper and coriander.',
    flavourDirection: 'Crisp pine-juniper opening, vibrant sea buckthorn citrus, warm heather-honey finish.',
    activeRecipeVersion: 'v1.0',
    imageUrl: '/assets/images/north_atlantic_bottle_1790507856346.jpg',
    recipeHistory: [
      {
        version: 'v0.1',
        label: 'Initial Bench Trial',
        createdAt: '2026-01-15',
        author: 'Master Distiller Angus MacLeod',
        notes: 'Bench scale 5L trial. Heavy heather, slightly subdued juniper.',
        baseSpiritType: 'Wheat Neutral Grain Spirit (96% ABV)',
        baseSpiritABV: 96.0,
        baseSpiritVolumeL: 100,
        botanicals: [
          { botanicalId: 'bot-juniper', botanicalName: 'Juniper Berries', gramsPerLitreBaseSpirit: 22, macerationHours: 12 },
          { botanicalId: 'bot-heather', botanicalName: 'Wild Heather Bloom', gramsPerLitreBaseSpirit: 8, macerationHours: 12 },
          { botanicalId: 'bot-seabuckthorn', botanicalName: 'Sea Buckthorn', gramsPerLitreBaseSpirit: 4, macerationHours: 12 },
        ],
        distillationMethod: 'POT_STILL',
        macerationTempC: 20,
        targetHeatskW: 18,
        headsCutPercent: 2.5,
        tailsCutPercent: 18.0,
        heartsABV: 79.0,
        restingDays: 10,
        targetABV: 43.0,
        filtrationType: 'UNFILTERED_CELLULOSE',
        status: 'ARCHIVED',
      },
      {
        version: 'v1.0',
        label: 'Production Commercial Standard',
        createdAt: '2026-03-01',
        author: 'Master Distiller Angus MacLeod',
        notes: 'Optimized juniper-citrus-heather equilibrium for 1000L still run.',
        baseSpiritType: 'Organic Scottish Wheat Spirit (96% ABV)',
        baseSpiritABV: 96.0,
        baseSpiritVolumeL: 1000,
        botanicals: [
          { botanicalId: 'bot-juniper', botanicalName: 'Juniper Berries', gramsPerLitreBaseSpirit: 28, macerationHours: 18 },
          { botanicalId: 'bot-coriander', botanicalName: 'Coriander Seed', gramsPerLitreBaseSpirit: 12, macerationHours: 18 },
          { botanicalId: 'bot-heather', botanicalName: 'Wild Heather Bloom', gramsPerLitreBaseSpirit: 5, macerationHours: 18 },
          { botanicalId: 'bot-seabuckthorn', botanicalName: 'Sea Buckthorn', gramsPerLitreBaseSpirit: 6, macerationHours: 18 },
          { botanicalId: 'bot-angelica', botanicalName: 'Angelica Root', gramsPerLitreBaseSpirit: 2.5, macerationHours: 18 },
          { botanicalId: 'bot-lemon', botanicalName: 'Fresh Lemon Peel', gramsPerLitreBaseSpirit: 8, macerationHours: 4 },
        ],
        distillationMethod: 'POT_STILL',
        macerationTempC: 22,
        targetHeatskW: 45,
        headsCutPercent: 2.0,
        tailsCutPercent: 15.0,
        heartsABV: 78.5,
        restingDays: 14,
        targetABV: 43.0,
        filtrationType: 'UNFILTERED_CELLULOSE',
        status: 'PRODUCTION',
      },
    ],
    flavourProfile: {
      juniper: 8.5,
      citrus: 7.8,
      floral: 6.4,
      spice: 5.2,
      herbal: 5.9,
      earthy: 4.8,
      woody: 4.5,
      sweet: 3.8,
      bitter: 2.5,
      fresh: 8.2,
      resinous: 7.1,
      mineral: 4.2,
    },
  };

  private stateSubject: BehaviorSubject<CompanyState>;
  public state$: Observable<CompanyState>;

  private scenariosSubject = new BehaviorSubject<TwinScenario[]>([]);
  public scenarios$ = this.scenariosSubject.asObservable();

  private eventLogsSubject = new BehaviorSubject<EventLogItem[]>([]);
  public eventLogs$ = this.eventLogsSubject.asObservable();

  constructor() {
    const initialState = this.buildInitialState();
    this.stateSubject = new BehaviorSubject<CompanyState>(initialState);
    this.state$ = this.stateSubject.asObservable();

    // Log initial seed event
    this.addEventLog('Digital Twin Initialized', 'Loaded North Atlantic Spirits base digital twin model.', 'State synchronized across all 21 modules.');
    
    // Seed initial scenario
    this.saveScenario('Base Case — Highland Distillery', 'Current operational baseline.');
  }

  public getState(): CompanyState {
    return this.stateSubject.getValue();
  }

  private buildInitialState(): CompanyState {
    const packaging: PackagingSpecification = {
      bottleType: 'Heavy Base Flint Glass 700ml',
      bottleWeightGrams: 650,
      bottleUnitCostGbp: 2.45,
      bottleSupplier: 'Ardagh Glass UK',
      closureType: 'Bespoke Wooden Top Natural Cork',
      closureUnitCostGbp: 0.62,
      labelType: 'Textured Cotton Paper with Copper Foil',
      labelUnitCostGbp: 0.38,
      cartonSizeBottles: 6,
      cartonUnitCostGbp: 1.80, // £0.30 per bottle share
      palletCapacityCases: 80, // 480 bottles
      freightCostPerPalletGbp: 120,
      recyclabilityPercent: 95,
    };

    const equipment: EquipmentAsset[] = [
      {
        id: 'eq-still-01',
        name: 'STILL 01 — "Caledonia" (1,000L Pot Still)',
        type: 'STILL',
        capacityLitre: 1000,
        status: 'RUNNING',
        temperatureC: 82.4,
        pressureBar: 1.08,
        powerKw: 45,
        currentBatchId: 'batch-2026-0048',
        healthPercent: 96,
        runHours: 1240,
        maintenanceDueDays: 45,
        capexValueGbp: 185000,
      },
      {
        id: 'eq-boiler-01',
        name: 'Steam Boiler Unit (500 kW)',
        type: 'BOILER',
        capacityLitre: 500,
        status: 'RUNNING',
        temperatureC: 118.2,
        pressureBar: 2.4,
        powerKw: 80,
        healthPercent: 94,
        runHours: 2100,
        maintenanceDueDays: 30,
        capexValueGbp: 45000,
      },
      {
        id: 'eq-condenser-01',
        name: 'Shell & Tube Copper Condenser',
        type: 'CONDENSER',
        capacityLitre: 300,
        status: 'RUNNING',
        temperatureC: 18.5,
        pressureBar: 1.0,
        powerKw: 12,
        healthPercent: 98,
        runHours: 1240,
        maintenanceDueDays: 90,
        capexValueGbp: 32000,
      },
      {
        id: 'eq-tank-01',
        name: 'Spirit Receiver Tank 01 (2,500L Stainless)',
        type: 'SPIRIT_TANK',
        capacityLitre: 2500,
        status: 'WAITING',
        temperatureC: 15.0,
        pressureBar: 1.0,
        powerKw: 0,
        healthPercent: 100,
        runHours: 850,
        maintenanceDueDays: 180,
        capexValueGbp: 22000,
      },
      {
        id: 'eq-bottling-01',
        name: 'Semi-Automated Bottling & Monoblock Line',
        type: 'BOTTLING_LINE',
        capacityLitre: 0,
        status: 'IDLE',
        temperatureC: 19.0,
        pressureBar: 1.0,
        powerKw: 15,
        healthPercent: 92,
        runHours: 620,
        maintenanceDueDays: 20,
        capexValueGbp: 110000,
      },
    ];

    const botanicalLots: BotanicalLot[] = [
      { lotNumber: 'LOT-J-8821', botanicalId: 'bot-juniper', botanicalName: 'Juniper Berries', supplier: 'Caledonian Botanicals Ltd', quantityKg: 148, reservedKg: 28, availableKg: 120, costPerKg: 18.5, receivedDate: '2026-02-10', expiryDate: '2027-02-10', qualityStatus: 'PASSED', moistureContent: 12.0 },
      { lotNumber: 'LOT-H-4412', botanicalId: 'bot-heather', botanicalName: 'Wild Heather Bloom', supplier: 'Highland Foragers Co', quantityKg: 35, reservedKg: 5, availableKg: 30, costPerKg: 42.0, receivedDate: '2026-02-15', expiryDate: '2026-08-15', qualityStatus: 'PASSED', moistureContent: 8.5 },
      { lotNumber: 'LOT-S-9121', botanicalId: 'bot-seabuckthorn', botanicalName: 'Sea Buckthorn', supplier: 'North Sea Organics', quantityKg: 42, reservedKg: 6, availableKg: 36, costPerKg: 38.0, receivedDate: '2026-02-12', expiryDate: '2026-10-12', qualityStatus: 'PASSED', moistureContent: 15.0 },
      { lotNumber: 'LOT-C-2218', botanicalId: 'bot-coriander', botanicalName: 'Coriander Seed', supplier: 'English Spice Merchants', quantityKg: 85, reservedKg: 12, availableKg: 73, costPerKg: 12.0, receivedDate: '2026-01-20', expiryDate: '2027-07-20', qualityStatus: 'PASSED', moistureContent: 9.0 },
    ];

    const batches: ProductionBatch[] = [
      {
        id: 'batch-2026-0048',
        batchNumber: '2026-0048',
        productName: 'NORTH ATLANTIC DRY GIN',
        recipeVersion: 'v1.0',
        scheduledDate: '2026-09-26',
        status: 'DISTILLING',
        baseSpiritVolumeL: 1000,
        rawMaterialsCostGbp: 1240,
        energyCostGbp: 180,
        labourCostGbp: 250,
        packagingCostGbp: 4830,
        overheadCostGbp: 320,
        totalBatchCostGbp: 6820,
        expectedBottles: 1250,
        actualBottlesProduced: 0,
        costPerBottleGbp: 5.45,
        assignedStillId: 'eq-still-01',
        botanicalLotNumbers: [
          { botanicalName: 'Juniper Berries', lotNumber: 'LOT-J-8821', kgUsed: 28 },
          { botanicalName: 'Coriander Seed', lotNumber: 'LOT-C-2218', kgUsed: 12 },
          { botanicalName: 'Wild Heather Bloom', lotNumber: 'LOT-H-4412', kgUsed: 5 },
          { botanicalName: 'Sea Buckthorn', lotNumber: 'LOT-S-9121', kgUsed: 6 },
        ],
        qcStatus: 'PENDING',
      },
      {
        id: 'batch-2026-0047',
        batchNumber: '2026-0047',
        productName: 'NORTH ATLANTIC DRY GIN',
        recipeVersion: 'v1.0',
        scheduledDate: '2026-09-18',
        completedDate: '2026-09-20',
        status: 'COMPLETED',
        baseSpiritVolumeL: 1000,
        rawMaterialsCostGbp: 1240,
        energyCostGbp: 180,
        labourCostGbp: 250,
        packagingCostGbp: 4830,
        overheadCostGbp: 320,
        totalBatchCostGbp: 6820,
        expectedBottles: 1250,
        actualBottlesProduced: 1242,
        costPerBottleGbp: 5.49,
        assignedStillId: 'eq-still-01',
        botanicalLotNumbers: [
          { botanicalName: 'Juniper Berries', lotNumber: 'LOT-J-8821', kgUsed: 28 },
          { botanicalName: 'Coriander Seed', lotNumber: 'LOT-C-2218', kgUsed: 12 },
        ],
        qcStatus: 'PASSED',
      },
    ];

    const qcRecords: QualityControlRecord[] = [
      {
        id: 'qc-0047',
        batchId: 'batch-2026-0047',
        batchNumber: '2026-0047',
        measuredABV: 43.1,
        measuredDensityGcm3: 0.942,
        clarityScore: 10,
        colour: 'Crystal Clear',
        sensoryScoreOverall: 9.4,
        operatorName: 'Fiona Campbell (Lead QC)',
        inspectionDate: '2026-09-21',
        status: 'PASS',
        notes: 'Exceptional clarity. Balanced juniper and heather aromas. Released to bottling.',
      },
    ];

    const sensoryScores: SensoryPanelScore[] = [
      {
        sampleName: 'Sample A (v1.0 Production)',
        panelistName: 'Angus MacLeod (Master Distiller)',
        nose: 9.2,
        juniper: 8.8,
        citrus: 8.0,
        floral: 7.2,
        herbal: 6.8,
        spice: 6.0,
        texture: 9.0,
        alcoholIntegration: 9.1,
        balance: 9.3,
        finish: 8.9,
        overallScore: 8.9,
      },
      {
        sampleName: 'Sample B (v0.1 Archival Trial)',
        panelistName: 'Angus MacLeod (Master Distiller)',
        nose: 7.5,
        juniper: 6.2,
        citrus: 5.8,
        floral: 8.5,
        herbal: 7.0,
        spice: 5.0,
        texture: 7.8,
        alcoholIntegration: 7.2,
        balance: 6.9,
        finish: 7.1,
        overallScore: 7.1,
      },
    ];

    const orders: CustomerOrder[] = [
      { id: 'ord-101', orderNumber: 'ORD-2026-881', customerName: 'The Balmoral Hotel Edinburgh', customerType: 'HOTEL', productName: 'NORTH ATLANTIC DRY GIN', quantityCases: 10, bottlesCount: 60, unitPriceGbp: 24.5, totalRevenueGbp: 1470, orderDate: '2026-09-22', status: 'DISPATCHED', allocatedBatchId: 'batch-2026-0047' },
      { id: 'ord-102', orderNumber: 'ORD-2026-882', customerName: 'Royal Mile Whiskies & Spirits', customerType: 'RETAIL', productName: 'NORTH ATLANTIC DRY GIN', quantityCases: 25, bottlesCount: 150, unitPriceGbp: 24.5, totalRevenueGbp: 3675, orderDate: '2026-09-24', status: 'ALLOCATED', allocatedBatchId: 'batch-2026-0047' },
      { id: 'ord-103', orderNumber: 'ORD-2026-883', customerName: 'Highland Fine Wine & Spirits Wholesaler', customerType: 'WHOLESALE', productName: 'NORTH ATLANTIC DRY GIN', quantityCases: 100, bottlesCount: 600, unitPriceGbp: 22.0, totalRevenueGbp: 13200, orderDate: '2026-09-25', status: 'CONFIRMED' },
    ];

    const stateWithoutRecalc: CompanyState = {
      companyName: 'NORTH ATLANTIC SPIRITS LTD',
      foundingYear: 2026,
      location: 'Cairngorms National Park, Inverness-shire, UK',
      initialCapitalGbp: 450000,
      product: this.defaultProduct,
      botanicals: this.defaultBotanicals,
      botanicalLots,
      packaging,
      equipment,
      batches,
      qcRecords,
      sensoryScores,
      orders,
      financials: {
        companyValuationGbp: 2850000,
        cashBalanceGbp: 215000,
        monthlyRevenueGbp: 38500,
        monthlyCogsGbp: 12200,
        grossMarginPercent: 68.3,
        bottlesProducedYtd: 14800,
        bottlesSoldYtd: 12600,
        currentInventoryBottles: 2200,
        annualProductionCapacityBottles: 55000,
        capacityUtilisationPercent: 26.9,
        costPerBottleGbp: 5.48,
        avgRetailPriceGbp: 42.0,
        avgWholesalePriceGbp: 24.5,
        contributionMarginGbp: 19.02,
        runwayMonths: 18.5,
        ebitdaGbp: 142000,
      },
      sustainability: {
        energyKwhPerBottle: 0.38,
        waterLitresPerBottle: 4.2,
        glassMassKgPerBottle: 0.65,
        transportDistanceKm: 185,
        carbonFootprintKgCo2ePerBottle: 1.12,
      },
    };

    return this.recalculateCausalState(stateWithoutRecalc);
  }

  // --- DIGITAL TWIN CAUSAL ENGINE ---
  // Calculates all derived parameters across the entire system
  public recalculateCausalState(state: CompanyState): CompanyState {
    const s = JSON.parse(JSON.stringify(state)) as CompanyState;
    const prod = s.product;
    const activeRecipe = prod.recipeHistory.find((r) => r.version === prod.activeRecipeVersion) || prod.recipeHistory[0];

    // 1. Calculate Botanical Cost per Batch
    let totalBotanicalCostGbp = 0;
    const baseSpiritL = activeRecipe.baseSpiritVolumeL; // e.g., 1000L

    activeRecipe.botanicals.forEach((dos) => {
      const botanical = s.botanicals.find((b) => b.id === dos.botanicalId);
      const pricePerKg = botanical ? botanical.pricePerKg : 20.0;
      const kgNeeded = (dos.gramsPerLitreBaseSpirit * baseSpiritL) / 1000.0;
      totalBotanicalCostGbp += kgNeeded * pricePerKg;
    });

    // 2. Spirit Cost
    const spiritCostPerLitre = 2.1; // Organic Wheat Neutral Spirit £2.10/L
    const spiritCostGbp = baseSpiritL * spiritCostPerLitre;

    // 3. Expected Yield in 700ml Bottles
    // 1000L at 96% ABV = 960 L pure alc. After heads (2%) & tails (15%) cut -> 83% alc recovered in hearts = 796.8 L pure alc.
    // At target 43% ABV -> 796.8 / 0.43 = 1853 L dilutied gin at 43% ABV.
    const pureAlcInput = baseSpiritL * (activeRecipe.baseSpiritABV / 100.0);
    const heartsRecovery = 1.0 - (activeRecipe.headsCutPercent + activeRecipe.tailsCutPercent) / 100.0;
    const heartsPureAlc = pureAlcInput * heartsRecovery;
    const dilutedGinVolumeL = heartsPureAlc / (prod.abvPercent / 100.0);
    const expectedBottlesCount = Math.floor(dilutedGinVolumeL / (prod.bottleVolumeMl / 1000.0));

    // 4. Packaging Cost per Bottle
    const pkg = s.packaging;
    const packagingCostPerBottle =
      pkg.bottleUnitCostGbp +
      pkg.closureUnitCostGbp +
      pkg.labelUnitCostGbp +
      pkg.cartonUnitCostGbp / pkg.cartonSizeBottles;

    // 5. Utilities & Labour per Batch
    const distillationEnergyKwh = baseSpiritL * 0.45; // 0.45 kWh per Litre
    const energyCostPerBatch = distillationEnergyKwh * 0.28; // £0.28 per kWh
    const labourCostPerBatch = 250.0; // Fixed operator cost
    const overheadPerBatch = 320.0;

    const totalBatchCost = spiritCostGbp + totalBotanicalCostGbp + energyCostPerBatch + labourCostPerBatch + overheadPerBatch + packagingCostPerBottle * expectedBottlesCount;
    const unitCostPerBottle = expectedBottlesCount > 0 ? totalBatchCost / expectedBottlesCount : 5.5;

    // 6. Flavour Profile Vector Calculation
    const newFlavour: FlavourProfile = {
      juniper: 2.0,
      citrus: 2.0,
      floral: 1.5,
      spice: 1.5,
      herbal: 1.5,
      earthy: 1.0,
      woody: 1.0,
      sweet: 1.0,
      bitter: 1.0,
      fresh: 2.0,
      resinous: 2.0,
      mineral: 1.0,
    };

    activeRecipe.botanicals.forEach((dos) => {
      const b = s.botanicals.find((bot) => bot.id === dos.botanicalId);
      if (!b) return;
      const weight = dos.gramsPerLitreBaseSpirit * b.intensityScore * b.extractionIndex * 0.015;

      if (b.category === 'core') {
        newFlavour.juniper += weight * 2.8;
        newFlavour.resinous += weight * 2.2;
        newFlavour.woody += weight * 1.2;
      } else if (b.category === 'citrus') {
        newFlavour.citrus += weight * 2.9;
        newFlavour.fresh += weight * 2.4;
      } else if (b.category === 'floral') {
        newFlavour.floral += weight * 3.1;
        newFlavour.sweet += weight * 1.8;
      } else if (b.category === 'spice') {
        newFlavour.spice += weight * 2.8;
        newFlavour.woody += weight * 1.5;
      } else if (b.category === 'earthy') {
        newFlavour.earthy += weight * 3.0;
        newFlavour.bitter += weight * 1.2;
      } else if (b.category === 'herbal') {
        newFlavour.herbal += weight * 2.7;
        newFlavour.fresh += weight * 1.6;
      }
    });

    // Cap profile scores between 1 and 10
    (Object.keys(newFlavour) as (keyof FlavourProfile)[]).forEach((key) => {
      newFlavour[key] = Math.min(10, Math.max(1, Number(newFlavour[key].toFixed(1))));
    });
    prod.flavourProfile = newFlavour;

    // 7. Update Financial Metrics
    const wholesalePrice = prod.targetWholesalePriceGbp;
    const contributionPerBottle = wholesalePrice - unitCostPerBottle;
    const grossMargin = wholesalePrice > 0 ? ((wholesalePrice - unitCostPerBottle) / wholesalePrice) * 100.0 : 65.0;

    // Still Capacity & Annual Limits
    const batchesPerYearMax = 220; // 5 days/week * 44 weeks
    const annualCapacityBottles = expectedBottlesCount * batchesPerYearMax;
    const currentBatchesRunYtd = 12;
    const capacityUtilisation = annualCapacityBottles > 0 ? ((currentBatchesRunYtd * expectedBottlesCount) / annualCapacityBottles) * 100.0 : 25.0;

    // Financial model numbers
    s.financials.costPerBottleGbp = Number(unitCostPerBottle.toFixed(2));
    s.financials.contributionMarginGbp = Number(contributionPerBottle.toFixed(2));
    s.financials.grossMarginPercent = Number(grossMargin.toFixed(1));
    s.financials.annualProductionCapacityBottles = annualCapacityBottles;
    s.financials.capacityUtilisationPercent = Number(capacityUtilisation.toFixed(1));
    s.financials.avgRetailPriceGbp = prod.targetRetailPriceGbp;
    s.financials.avgWholesalePriceGbp = prod.targetWholesalePriceGbp;

    // Recalculate Sustainability Metrics
    s.sustainability.energyKwhPerBottle = Number((distillationEnergyKwh / (expectedBottlesCount || 1)).toFixed(2));
    s.sustainability.glassMassKgPerBottle = Number((pkg.bottleWeightGrams / 1000.0).toFixed(2));
    s.sustainability.carbonFootprintKgCo2ePerBottle = Number(
      (
        pkg.bottleWeightGrams * 0.0012 + // glass carbon
        (distillationEnergyKwh / expectedBottlesCount) * 0.22 + // electric carbon
        totalBotanicalCostGbp * 0.0001
      ).toFixed(2)
    );

    return s;
  }

  // --- ACTIONS & MUTATORS ---

  public updateProduct(updated: Partial<ProductSpecification>): void {
    const currentState = this.getState();
    currentState.product = { ...currentState.product, ...updated };
    const newState = this.recalculateCausalState(currentState);
    this.stateSubject.next(newState);
    this.addEventLog('Product Specification Updated', `Updated product settings: ${Object.keys(updated).join(', ')}.`, `COGS updated to £${newState.financials.costPerBottleGbp}/bottle.`);
  }

  public updatePackaging(updated: Partial<PackagingSpecification>): void {
    const currentState = this.getState();
    currentState.packaging = { ...currentState.packaging, ...updated };
    const newState = this.recalculateCausalState(currentState);
    this.stateSubject.next(newState);
    this.addEventLog('Packaging Design Modified', `Updated packaging parameters: ${Object.keys(updated).join(', ')}.`, `Packaging unit cost recalculated to £${(newState.packaging.bottleUnitCostGbp + newState.packaging.closureUnitCostGbp + newState.packaging.labelUnitCostGbp).toFixed(2)}.`);
  }

  public updateRecipeBotanicalDosage(botanicalId: string, gramsPerLitre: number): void {
    const currentState = this.getState();
    const prod = currentState.product;
    const recipe = prod.recipeHistory.find((r) => r.version === prod.activeRecipeVersion);
    if (!recipe) return;

    const dosage = recipe.botanicals.find((b) => b.botanicalId === botanicalId);
    if (dosage) {
      dosage.gramsPerLitreBaseSpirit = gramsPerLitre;
    } else {
      const b = currentState.botanicals.find((bot) => bot.id === botanicalId);
      if (b) {
        recipe.botanicals.push({
          botanicalId,
          botanicalName: b.commonName,
          gramsPerLitreBaseSpirit: gramsPerLitre,
          macerationHours: 18,
        });
      }
    }

    const newState = this.recalculateCausalState(currentState);
    this.stateSubject.next(newState);
    this.addEventLog('Recipe Botanical Adjusted', `Adjusted botanical dosage for ${botanicalId} to ${gramsPerLitre} g/L.`, `Flavour vector recalculated & batch cost updated.`);
  }

  public addBotanical(botanical: Botanical): void {
    const currentState = this.getState();
    currentState.botanicals.push(botanical);
    const newState = this.recalculateCausalState(currentState);
    this.stateSubject.next(newState);
    this.addEventLog('New Botanical Added', `Added botanical ${botanical.commonName} (${botanical.latinName}).`, 'Botanical library expanded.');
  }

  public createNewBatch(assignedStillId: string): ProductionBatch {
    const currentState = this.getState();
    const batchCount = currentState.batches.length + 1;
    const batchNum = `2026-00${48 + batchCount}`;

    const newBatch: ProductionBatch = {
      id: `batch-${batchNum}`,
      batchNumber: batchNum,
      productName: currentState.product.name,
      recipeVersion: currentState.product.activeRecipeVersion,
      scheduledDate: new Date().toISOString().split('T')[0],
      status: 'PLANNED',
      baseSpiritVolumeL: 1000,
      rawMaterialsCostGbp: 1240,
      energyCostGbp: 180,
      labourCostGbp: 250,
      packagingCostGbp: 4830,
      overheadCostGbp: 320,
      totalBatchCostGbp: 6820,
      expectedBottles: 1250,
      actualBottlesProduced: 0,
      costPerBottleGbp: currentState.financials.costPerBottleGbp,
      assignedStillId,
      botanicalLotNumbers: currentState.botanicalLots.map((l) => ({ botanicalName: l.botanicalName, lotNumber: l.lotNumber, kgUsed: 10 })),
      qcStatus: 'PENDING',
    };

    currentState.batches.unshift(newBatch);
    const newState = this.recalculateCausalState(currentState);
    this.stateSubject.next(newState);
    this.addEventLog('New Batch Scheduled', `Created batch ${batchNum} for 1,000L distillation.`, 'Reserved raw materials in inventory.');
    return newBatch;
  }

  public updateBatchStatus(batchId: string, status: ProductionBatch['status']): void {
    const currentState = this.getState();
    const batch = currentState.batches.find((b) => b.id === batchId);
    if (batch) {
      batch.status = status;
      if (status === 'COMPLETED') {
        batch.actualBottlesProduced = batch.expectedBottles - Math.floor(Math.random() * 12);
        currentState.financials.currentInventoryBottles += batch.actualBottlesProduced;
        currentState.financials.bottlesProducedYtd += batch.actualBottlesProduced;
      }
      const newState = this.recalculateCausalState(currentState);
      this.stateSubject.next(newState);
      this.addEventLog('Batch Lifecycle Progression', `Batch ${batch.batchNumber} moved to ${status}.`, `Inventory updated.`);
    }
  }

  public submitQCRecord(record: QualityControlRecord): void {
    const currentState = this.getState();
    currentState.qcRecords.unshift(record);
    const batch = currentState.batches.find((b) => b.id === record.batchId);
    if (batch) {
      batch.qcStatus = record.status === 'PASS' ? 'PASSED' : 'HOLD';
    }
    const newState = this.recalculateCausalState(currentState);
    this.stateSubject.next(newState);
    this.addEventLog('QC Inspection Completed', `Batch ${record.batchNumber} evaluated as ${record.status}.`, `Overall sensory score: ${record.sensoryScoreOverall}/10.`);
  }

  public submitSensoryScore(score: SensoryPanelScore): void {
    const currentState = this.getState();
    currentState.sensoryScores.unshift(score);
    this.stateSubject.next(currentState);
  }

  public addCustomerOrder(order: CustomerOrder): void {
    const currentState = this.getState();
    currentState.orders.unshift(order);
    currentState.financials.monthlyRevenueGbp += order.totalRevenueGbp;
    currentState.financials.bottlesSoldYtd += order.bottlesCount;
    currentState.financials.currentInventoryBottles = Math.max(0, currentState.financials.currentInventoryBottles - order.bottlesCount);
    const newState = this.recalculateCausalState(currentState);
    this.stateSubject.next(newState);
    this.addEventLog('New Sales Order Received', `Order ${order.orderNumber} for ${order.bottlesCount} bottles (${order.customerName}).`, `Total Revenue +£${order.totalRevenueGbp.toLocaleString()}.`);
  }

  // --- FOUNDER WIZARD: "BUILD MY GIN" ---
  public generateFounderGinCompany(
    ginType: string,
    location: string,
    targetVolume: number,
    retailPrice: number,
    capitalGbp: number
  ): void {
    const currentState = this.getState();

    currentState.product.name = `${ginType.toUpperCase()} GIN`;
    currentState.product.commercialCategory = ginType;
    currentState.product.originRegion = location;
    currentState.product.targetRetailPriceGbp = retailPrice;
    currentState.product.targetWholesalePriceGbp = Number((retailPrice * 0.58).toFixed(2));
    currentState.initialCapitalGbp = capitalGbp;
    currentState.financials.cashBalanceGbp = capitalGbp;
    currentState.financials.annualProductionCapacityBottles = targetVolume;

    const newState = this.recalculateCausalState(currentState);
    this.stateSubject.next(newState);
    this.addEventLog('Founder Mode Initialized', `Generated brand new gin company structure for ${ginType}.`, `Target Volume: ${targetVolume.toLocaleString()} bottles/yr.`);
  }

  // --- SCENARIO LAB ---
  public saveScenario(name: string, description: string): void {
    const currentState = this.getState();
    const scenario: TwinScenario = {
      id: `scen-${Date.now()}`,
      name,
      description,
      state: JSON.parse(JSON.stringify(currentState)),
      createdAt: new Date().toISOString(),
    };
    const updatedScenarios = [...this.scenariosSubject.getValue(), scenario];
    this.scenariosSubject.next(updatedScenarios);
    this.addEventLog('Scenario Branch Saved', `Saved state snapshot "${name}".`, `Scenario lab updated.`);
  }

  public loadScenario(scenarioId: string): void {
    const scenario = this.scenariosSubject.getValue().find((s) => s.id === scenarioId);
    if (scenario) {
      const restoredState = this.recalculateCausalState(JSON.parse(JSON.stringify(scenario.state)));
      this.stateSubject.next(restoredState);
      this.addEventLog('Scenario Loaded', `Switched digital twin to scenario "${scenario.name}".`, `All 21 modules restored to snapshot state.`);
    }
  }

  // --- TRACEABILITY & RECALL SIMULATOR ---
  public traceLotImpact(lotNumber: string): { batches: ProductionBatch[]; orders: CustomerOrder[]; totalBottles: number } {
    const state = this.getState();
    const affectedBatches = state.batches.filter((b) =>
      b.botanicalLotNumbers.some((l) => l.lotNumber.toUpperCase() === lotNumber.toUpperCase())
    );
    const affectedBatchIds = affectedBatches.map((b) => b.id);
    const affectedOrders = state.orders.filter((o) => o.allocatedBatchId && affectedBatchIds.includes(o.allocatedBatchId));
    const totalBottles = affectedOrders.reduce((sum, o) => sum + o.bottlesCount, 0);

    return { batches: affectedBatches, orders: affectedOrders, totalBottles };
  }

  private addEventLog(eventType: string, description: string, impactSummary: string): void {
    const logs = this.eventLogsSubject.getValue();
    const newLog: EventLogItem = {
      id: `evt-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      eventType,
      description,
      impactSummary,
    };
    this.eventLogsSubject.next([newLog, ...logs.slice(0, 49)]);
  }
}
