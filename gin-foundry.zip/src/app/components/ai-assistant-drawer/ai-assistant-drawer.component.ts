import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CompanyState } from '../../models/digital-twin.model';

interface ChatMessage {
  sender: 'USER' | 'AI';
  text: string;
  timestamp: string;
}

@Component({
  selector: 'app-ai-assistant-drawer',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div
      *ngIf="isOpen"
      class="fixed inset-y-0 right-0 z-50 w-full sm:w-[460px] bg-[#121824] border-l border-slate-800 shadow-2xl flex flex-col justify-between"
    >
      <!-- HEADER -->
      <div class="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/80">
        <div class="flex items-center gap-2">
          <div class="w-8 h-8 rounded-lg bg-amber-600/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
            <span class="material-icons text-base">psychology</span>
          </div>
          <div>
            <h3 class="font-serif-brand font-bold text-white text-sm">AI Gin Foundry Assistant</h3>
            <p class="text-[10px] font-mono-data text-amber-400">GEMINI 3.8 FLASH · REAL-TIME STATE CONTEXT</p>
          </div>
        </div>

        <button (click)="close.emit()" class="text-slate-400 hover:text-white p-1">✕</button>
      </div>

      <!-- CHAT MESSAGES BODY -->
      <div class="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
        <div *ngFor="let msg of messages" class="space-y-1">
          <div
            [class.text-amber-400]="msg.sender === 'AI'"
            [class.text-sky-400]="msg.sender === 'USER'"
            class="text-[10px] font-mono-data uppercase font-bold"
          >
            {{ msg.sender === 'AI' ? 'GIN FOUNDRY AI' : 'FOUNDER' }} · {{ msg.timestamp }}
          </div>

          <div
            [class.bg-slate-900]="msg.sender === 'AI'"
            [class.border-amber-500\/30]="msg.sender === 'AI'"
            [class.bg-slate-800]="msg.sender === 'USER'"
            [class.border-slate-700]="msg.sender === 'USER'"
            class="p-3 rounded-xl border text-xs text-slate-200 leading-relaxed font-sans whitespace-pre-wrap"
          >
            {{ msg.text }}
          </div>
        </div>

        <div *ngIf="loading" class="flex items-center gap-2 text-xs font-mono-data text-amber-400 animate-pulse p-2">
          <span class="material-icons text-sm">autorenew</span>
          <span>Analyzing company state & generating grounded response...</span>
        </div>
      </div>

      <!-- SUGGESTED PROMPTS & INPUT -->
      <div class="p-4 border-t border-slate-800 bg-slate-900/90 space-y-3">
        <!-- Quick Prompts Strip -->
        <div class="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-[10px] font-mono-data">
          <button
            *ngFor="let q of quickQuestions"
            (click)="userPrompt = q; sendMessage()"
            class="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 whitespace-nowrap shrink-0"
          >
            {{ q }}
          </button>
        </div>

        <div class="flex items-center gap-2">
          <input
            type="text"
            [(ngModel)]="userPrompt"
            (keyup.enter)="sendMessage()"
            placeholder="Ask about COGS, recipe, botanicals, capacity..."
            class="flex-1 bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:border-amber-500 outline-none"
          />

          <button
            (click)="sendMessage()"
            [disabled]="loading || !userPrompt.trim()"
            class="px-3 py-2 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white rounded-lg text-xs font-semibold"
          >
            Send
          </button>
        </div>
      </div>
    </div>
  `,
})
export class AiAssistantDrawerComponent {
  @Input() isOpen = false;
  @Input() state!: CompanyState;
  @Output() close = new EventEmitter<void>();

  loading = false;
  userPrompt = '';

  quickQuestions = [
    'Why did batch cost change?',
    'Which botanicals drive cost?',
    'What happens if I produce 250,000 bottles?',
    'Trace supplier risk',
  ];

  messages: ChatMessage[] = [
    {
      sender: 'AI',
      text: 'Welcome to GIN FOUNDRY AI. I have live access to North Atlantic Spirits Ltd digital twin state. How can I assist with your recipe, costing, or scale-up strategy?',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ];

  async sendMessage() {
    if (!this.userPrompt.trim() || this.loading) return;

    const promptText = this.userPrompt.trim();
    this.userPrompt = '';

    this.messages.push({
      sender: 'USER',
      text: promptText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    });

    this.loading = true;

    try {
      const res = await fetch('/api/v1/ai/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: promptText,
          stateContext: {
            companyName: this.state.companyName,
            product: this.state.product,
            activeRecipe: this.state.product.recipeHistory.find((r) => r.version === this.state.product.activeRecipeVersion),
            cogsPerBottle: this.state.financials.costPerBottleGbp,
            grossMargin: this.state.financials.grossMarginPercent,
            capacityBottles: this.state.financials.annualProductionCapacityBottles,
            cashBalance: this.state.financials.cashBalanceGbp,
            botanicalLots: this.state.botanicalLots,
            recentBatches: this.state.batches.slice(0, 3),
          },
        }),
      });

      const data = await res.json();
      const answer = data.answer || 'Processing complete.';

      this.messages.push({
        sender: 'AI',
        text: answer,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      });
    } catch (err) {
      this.messages.push({
        sender: 'AI',
        text: 'Apologies, unable to connect to Gemini AI Assistant backend service.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      });
    } finally {
      this.loading = false;
    }
  }
}
