import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CompanyState, FlavourProfile, SensoryPanelScore } from '../../models/digital-twin.model';

@Component({
  selector: 'app-lab',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="space-y-8 pb-12">
      
      <!-- HEADER -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div class="text-xs font-mono-data text-amber-400 mb-1">MODULE 07, 08, 11 & 12 // PILOT BATCH LAB & SENSORY PANEL</div>
          <h1 class="font-serif-brand text-2xl sm:text-3xl font-bold text-white">Product Laboratory & Sensory Panel</h1>
          <p class="text-xs text-slate-400 mt-1">
            Simulate distillation cuts, model 12-dimensional flavour profiles, and evaluate blind sensory panel scores with statistical variance.
          </p>
        </div>

        <button
          (click)="blindMode = !blindMode"
          [class.bg-amber-600]="blindMode"
          [class.bg-slate-800]="!blindMode"
          class="px-4 py-2 text-xs font-semibold rounded-lg text-white border border-slate-700 shadow-md transition-all flex items-center gap-1.5"
        >
          <span class="material-icons text-sm">visibility_off</span>
          <span>{{ blindMode ? 'BLIND TASTING MODE ACTIVE' : 'ENABLE BLIND COMPARISON' }}</span>
        </button>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        <!-- 12-DIMENSIONAL RADIAL FLAVOUR PROFILE (6 cols) -->
        <div class="lg:col-span-6 bg-[#121824] border border-slate-800 rounded-2xl p-6 space-y-6">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 class="font-serif-brand text-lg font-bold text-white">12-Dimensional Flavour Model</h3>
              <p class="text-xs text-slate-400">Predicted sensory vector derived from botanical dosage & extraction index.</p>
            </div>
            <span class="text-xs font-mono-data text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded">
              v1.0 MODEL
            </span>
          </div>

          <!-- Flavour Vector Attribute Bars -->
          <div class="grid grid-cols-2 gap-x-6 gap-y-3 text-xs">
            <div *ngFor="let attr of flavourKeys" class="space-y-1">
              <div class="flex justify-between font-mono-data">
                <span class="capitalize text-slate-300 font-medium">{{ attr }}</span>
                <span class="text-amber-400 font-bold">{{ state.product.flavourProfile[attr] }} / 10</span>
              </div>
              <div class="w-full bg-slate-900 h-2 rounded-full overflow-hidden border border-slate-800">
                <div
                  class="bg-gradient-to-r from-amber-600 to-amber-400 h-full transition-all duration-300"
                  [style.width.%]="state.product.flavourProfile[attr] * 10"
                ></div>
              </div>
            </div>
          </div>

          <div class="p-3 rounded-lg bg-slate-900/80 border border-slate-800 text-[11px] text-slate-400 font-mono-data flex items-center gap-2">
            <span class="material-icons text-amber-400 text-sm">info</span>
            <span>Note: Flavour predictions are mathematical process models calibrated against historical panel sensory scores.</span>
          </div>
        </div>

        <!-- DISTILLATION CUTS SIMULATOR (6 cols) -->
        <div class="lg:col-span-6 bg-[#121824] border border-slate-800 rounded-2xl p-6 space-y-6">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 class="font-serif-brand text-lg font-bold text-white">Distillation Cut Fractionation</h3>
              <p class="text-xs text-slate-400">Simulated spirit cuts: Heads (Foreshots/Esters), Hearts (Ethanol/Botanicals), Tails (Fusels).</p>
            </div>
            <span class="text-xs font-mono-data text-sky-400">1,000L STILL RUN</span>
          </div>

          <!-- Cut Fractions Display -->
          <div class="space-y-4">
            
            <div class="space-y-1">
              <div class="flex justify-between text-xs font-mono-data">
                <span class="text-rose-400 font-bold">01. HEADS CUT (2.0%)</span>
                <span class="text-slate-300">~20 Litres at 84% ABV</span>
              </div>
              <div class="p-2.5 rounded-lg bg-rose-950/30 border border-rose-500/20 text-xs text-slate-300">
                Contains light esters, acetaldehyde, ethyl acetate. Recycled or discarded.
              </div>
            </div>

            <div class="space-y-1">
              <div class="flex justify-between text-xs font-mono-data">
                <span class="text-emerald-400 font-bold">02. HEARTS CUT (83.0%)</span>
                <span class="text-emerald-300 font-bold">~830 Litres at 78.5% ABV</span>
              </div>
              <div class="p-3 rounded-lg bg-emerald-950/30 border border-emerald-500/30 text-xs text-slate-200">
                Clean, crisp heart fraction containing peak pinene, linalool, and sea buckthorn citrus. Diluted to {{ state.product.abvPercent }}% ABV.
              </div>
            </div>

            <div class="space-y-1">
              <div class="flex justify-between text-xs font-mono-data">
                <span class="text-amber-400 font-bold">03. TAILS CUT (15.0%)</span>
                <span class="text-slate-300">~150 Litres at 32% ABV</span>
              </div>
              <div class="p-2.5 rounded-lg bg-amber-950/30 border border-amber-500/20 text-xs text-slate-300">
                Heavy fusel oils and bitter angelica root compounds. Diverted to low wines receiver.
              </div>
            </div>

          </div>
        </div>

      </div>

      <!-- SENSORY PANEL TASTING INTERFACE -->
      <div class="bg-[#121824] border border-slate-800 rounded-2xl p-6 space-y-6">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div>
            <h3 class="font-serif-brand text-lg font-bold text-white">Sensory Tasting Evaluation Panel</h3>
            <p class="text-xs text-slate-400">Statistical sensory scores submitted by master distillers and certified spirit judges.</p>
          </div>

          <button (click)="showSensoryForm = true" class="px-3 py-1.5 text-xs font-semibold rounded-lg bg-amber-600 hover:bg-amber-500 text-white shadow">
            + SUBMIT PANEL TASTING SCORE
          </button>
        </div>

        <!-- Sensory Scores List -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div
            *ngFor="let s of state.sensoryScores; let i = index"
            class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-3"
          >
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <span class="font-bold font-serif-brand text-white text-sm">
                {{ blindMode ? 'Blind Sample ' + (i === 0 ? 'X' : 'Y') : s.sampleName }}
              </span>
              <span class="text-xs font-mono-data text-emerald-400 font-bold bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded">
                SCORE: {{ s.overallScore }} / 10
              </span>
            </div>

            <div class="grid grid-cols-3 gap-2 text-[11px] font-mono-data text-slate-300">
              <div>Nose: <span class="text-amber-400">{{ s.nose }}</span></div>
              <div>Juniper: <span class="text-amber-400">{{ s.juniper }}</span></div>
              <div>Citrus: <span class="text-amber-400">{{ s.citrus }}</span></div>
              <div>Floral: <span class="text-amber-400">{{ s.floral }}</span></div>
              <div>Herbal: <span class="text-amber-400">{{ s.herbal }}</span></div>
              <div>Spice: <span class="text-amber-400">{{ s.spice }}</span></div>
              <div>Texture: <span class="text-amber-400">{{ s.texture }}</span></div>
              <div>Integration: <span class="text-amber-400">{{ s.alcoholIntegration }}</span></div>
              <div>Finish: <span class="text-amber-400">{{ s.finish }}</span></div>
            </div>

            <div class="text-[10px] text-slate-500 font-mono-data pt-2 border-t border-slate-800/60">
              Evaluator: {{ blindMode ? 'Panelist #' + (i + 1) : s.panelistName }}
            </div>
          </div>
        </div>
      </div>

    </div>
  `,
})
export class LabComponent {
  @Input() state!: CompanyState;
  @Output() submitSensory = new EventEmitter<SensoryPanelScore>();

  blindMode = false;
  showSensoryForm = false;

  get flavourKeys(): (keyof FlavourProfile)[] {
    return [
      'juniper',
      'citrus',
      'floral',
      'spice',
      'herbal',
      'earthy',
      'woody',
      'sweet',
      'bitter',
      'fresh',
      'resinous',
      'mineral',
    ];
  }
}
