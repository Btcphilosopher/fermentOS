import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CompanyState, TwinScenario } from '../../models/digital-twin.model';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule],
  template: `
    <header class="bg-[#121824] border-b border-slate-800 sticky top-0 z-40 shadow-xl">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between h-16">
          
          <!-- Zone 1: Single-element Brand Wordmark -->
          <div class="flex items-center gap-3 shrink-0">
            <div class="w-9 h-9 rounded-lg bg-gradient-to-br from-amber-600 via-amber-700 to-yellow-800 flex items-center justify-center shadow-md border border-amber-500/30">
              <span class="font-serif-brand font-bold text-lg text-amber-100">G</span>
            </div>
            <div>
              <div class="font-serif-brand font-bold text-xl tracking-wider text-amber-100 uppercase">GIN FOUNDRY</div>
              <div class="text-[10px] font-mono-data text-amber-400/80 tracking-widest uppercase -mt-1">DISTILLERY DIGITAL TWIN</div>
            </div>
          </div>

          <!-- Zone 2: Navigation Links -->
          <nav class="hidden xl:flex items-center gap-1 text-xs font-medium text-slate-300">
            <button
              *ngFor="let tab of navTabs"
              (click)="selectTab(tab.id)"
              [class.bg-amber-500/10]="activeTab === tab.id"
              [class.text-amber-400]="activeTab === tab.id"
              [class.border-amber-500/50]="activeTab === tab.id"
              class="px-3 py-1.5 rounded-md border border-transparent hover:text-white hover:bg-slate-800/60 transition-all duration-150 whitespace-nowrap"
            >
              {{ tab.label }}
            </button>
          </nav>

          <!-- Zone 3: Actions & Scenario Switcher -->
          <div class="flex items-center gap-2">
            <!-- Scenario Selector -->
            <div class="relative hidden sm:block">
              <select
                (change)="onScenarioChange($event)"
                class="bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded-lg px-2.5 py-1.5 font-mono-data focus:ring-1 focus:ring-amber-500 outline-none"
              >
                <option *ngFor="let sc of scenarios" [value]="sc.id">
                  ⚡ {{ sc.name }}
                </option>
              </select>
            </div>

            <!-- Founder Wizard Action -->
            <button
              (click)="openFounderWizard.emit()"
              class="px-3 py-1.5 text-xs font-semibold rounded-lg bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white shadow-sm transition-all whitespace-nowrap flex items-center gap-1.5 border border-amber-500/30"
            >
              <span class="text-sm">✦</span>
              <span>BUILD MY GIN</span>
            </button>

            <!-- AI Assistant Drawer Button -->
            <button
              (click)="toggleAiDrawer.emit()"
              class="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-400 border border-slate-700 transition-colors flex items-center justify-center"
              title="Open AI Digital Twin Assistant"
            >
              <span class="material-icons text-base">psychology</span>
            </button>
          </div>

        </div>

        <!-- Mobile & Tablet Scrollable Nav -->
        <div class="xl:hidden flex items-center gap-1 overflow-x-auto py-2 border-t border-slate-800/80 text-xs no-scrollbar">
          <button
            *ngFor="let tab of navTabs"
            (click)="selectTab(tab.id)"
            [class.bg-amber-500/10]="activeTab === tab.id"
            [class.text-amber-400]="activeTab === tab.id"
            class="px-2.5 py-1 rounded border border-transparent hover:text-white whitespace-nowrap shrink-0"
          >
            {{ tab.label }}
          </button>
        </div>

      </div>
    </header>
  `,
})
export class HeaderComponent {
  @Input() activeTab = 'overview';
  @Input() scenarios: TwinScenario[] = [];
  @Input() state!: CompanyState;

  @Output() activeTabChange = new EventEmitter<string>();
  @Output() openFounderWizard = new EventEmitter<void>();
  @Output() openScaleUpWizard = new EventEmitter<void>();
  @Output() toggleAiDrawer = new EventEmitter<void>();
  @Output() scenarioSelect = new EventEmitter<string>();

  navTabs = [
    { id: 'overview', label: 'FOUNDRY' },
    { id: 'products', label: 'PRODUCTS' },
    { id: 'recipes', label: 'RECIPES' },
    { id: 'botanicals', label: 'BOTANICALS' },
    { id: 'lab', label: 'LAB & SENSORY' },
    { id: 'distillery', label: 'DISTILLERY' },
    { id: 'production', label: 'MES & BATCHES' },
    { id: 'packaging', label: 'PACKAGING' },
    { id: 'costing', label: 'FINANCE & COGS' },
    { id: 'compliance', label: 'TRACEABILITY' },
    { id: 'scenarios', label: 'SCENARIO LAB' },
  ];

  selectTab(id: string) {
    this.activeTabChange.emit(id);
  }

  onScenarioChange(event: Event) {
    const target = event.target as HTMLSelectElement;
    if (target) {
      this.scenarioSelect.emit(target.value);
    }
  }
}
