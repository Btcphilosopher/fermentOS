import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-founder-wizard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div *ngIf="isOpen" class="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div class="bg-[#121824] border border-amber-500/40 rounded-2xl max-w-xl w-full p-6 space-y-6 shadow-2xl">
        
        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
          <div class="flex items-center gap-2">
            <span class="text-amber-400 font-bold text-lg">✦</span>
            <h3 class="font-serif-brand font-bold text-white text-lg">FOUNDER MODE — BUILD MY GIN</h3>
          </div>
          <button (click)="close.emit()" class="text-slate-400 hover:text-white">✕</button>
        </div>

        <p class="text-xs text-slate-300">
          Enter your initial gin concept details. GIN FOUNDRY will synthesize a complete connected initial digital twin model (Product, Recipe, Distillery Equipment, Financial Model, and Cash Flow).
        </p>

        <div class="space-y-4 text-xs">
          <div class="space-y-1">
            <label class="text-slate-300 font-medium">Gin Style / Concept</label>
            <input
              type="text"
              [(ngModel)]="ginType"
              placeholder="e.g. Scottish Coastal Dry Gin"
              class="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-100 outline-none focus:border-amber-500"
            />
          </div>

          <div class="space-y-1">
            <label class="text-slate-300 font-medium">Distillery Location</label>
            <input
              type="text"
              [(ngModel)]="location"
              placeholder="e.g. Inverness-shire, Scottish Highlands"
              class="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-100 outline-none focus:border-amber-500"
            />
          </div>

          <div class="grid grid-cols-2 gap-4">
            <div class="space-y-1">
              <label class="text-slate-300 font-medium">Target Annual Volume (Bottles)</label>
              <input
                type="number"
                [(ngModel)]="targetVolume"
                class="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-100 font-mono-data outline-none"
              />
            </div>

            <div class="space-y-1">
              <label class="text-slate-300 font-medium">Target Retail Price (£ RRP)</label>
              <input
                type="number"
                [(ngModel)]="retailPrice"
                class="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-100 font-mono-data outline-none"
              />
            </div>
          </div>

          <div class="space-y-1">
            <label class="text-slate-300 font-medium">Available Starting Capital (£)</label>
            <input
              type="number"
              [(ngModel)]="capitalGbp"
              class="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-100 font-mono-data outline-none"
            />
          </div>
        </div>

        <div class="flex justify-end gap-3 pt-3 border-t border-slate-800">
          <button (click)="close.emit()" class="px-4 py-2 text-xs text-slate-400 hover:text-white">Cancel</button>
          <button
            (click)="generateCompany()"
            class="px-5 py-2 text-xs font-semibold bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white rounded-lg shadow-lg"
          >
            SYNTHESIZE DIGITAL TWIN
          </button>
        </div>

      </div>
    </div>
  `,
})
export class FounderWizardComponent {
  @Input() isOpen = false;
  @Output() close = new EventEmitter<void>();
  @Output() buildGin = new EventEmitter<{
    ginType: string;
    location: string;
    targetVolume: number;
    retailPrice: number;
    capitalGbp: number;
  }>();

  ginType = 'Scottish Highland Dry Gin';
  location = 'Cairngorms National Park, Inverness-shire, UK';
  targetVolume = 50000;
  retailPrice = 42;
  capitalGbp = 450000;

  generateCompany() {
    this.buildGin.emit({
      ginType: this.ginType,
      location: this.location,
      targetVolume: this.targetVolume,
      retailPrice: this.retailPrice,
      capitalGbp: this.capitalGbp,
    });
    this.close.emit();
  }
}
