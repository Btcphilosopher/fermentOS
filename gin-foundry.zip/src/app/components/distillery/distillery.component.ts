import { Component, ElementRef, Input, ViewChild, AfterViewInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CompanyState, EquipmentAsset } from '../../models/digital-twin.model';
import * as THREE from 'three';

@Component({
  selector: 'app-distillery',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="space-y-8 pb-12">
      
      <!-- HEADER -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div class="text-xs font-mono-data text-amber-400 mb-1">MODULE 09, 10 & 32 // DISTILLERY DIGITAL TWIN (THREE.JS / WEBGL)</div>
          <h1 class="font-serif-brand text-2xl sm:text-3xl font-bold text-white">3D Stillhouse & Industrial Telemetry</h1>
          <p class="text-xs text-slate-400 mt-1">
            Real-time WebGL interactive 3D spatial twin mapped directly to equipment telemetry, boiler steam temperature, and still pressure.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <span class="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping"></span>
          <span class="text-xs font-mono-data text-emerald-400">TELEMETRY STREAM ONLINE (100 Hz)</span>
        </div>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        <!-- THREE.JS WEBGL 3D DIGITAL TWIN VIEWPORT (8 cols) -->
        <div class="lg:col-span-8 bg-[#121824] border border-slate-800 rounded-2xl p-4 space-y-3">
          <div class="flex items-center justify-between px-2 text-xs font-mono-data text-slate-400">
            <span class="text-amber-400 font-bold">3D DISTILLERY STILLHOUSE MODEL</span>
            <span>DRAG TO ORBIT · SCROLL TO ZOOM</span>
          </div>

          <div class="relative w-full h-[400px] rounded-xl overflow-hidden border border-slate-800 bg-slate-950">
            <div #threeCanvas class="w-full h-full"></div>

            <!-- Overlay Equipment Inspector Label -->
            <div *ngIf="selectedEquipment" class="absolute bottom-4 left-4 bg-slate-900/90 backdrop-blur border border-amber-500/40 p-3 rounded-lg text-xs space-y-1 font-mono-data">
              <div class="text-amber-400 font-bold">{{ selectedEquipment.name }}</div>
              <div class="text-slate-300">Status: <span class="text-emerald-400">{{ selectedEquipment.status }}</span></div>
              <div class="text-slate-300">Temp: {{ selectedEquipment.temperatureC }}°C · Power: {{ selectedEquipment.powerKw }} kW</div>
            </div>
          </div>
        </div>

        <!-- HERO STILLHOUSE PHOTO & QUICK STATS (4 cols) -->
        <div class="lg:col-span-4 space-y-6">
          <div class="bg-[#121824] border border-slate-800 rounded-2xl p-4 space-y-3">
            <img
              src="/src/assets/images/distillery_stillhouse_1790507867078.jpg"
              alt="Distillery Stillhouse"
              class="rounded-xl w-full h-48 object-cover border border-slate-800 shadow-xl"
            />
            <div class="text-xs space-y-2 text-slate-300">
              <div class="font-serif-brand font-bold text-white text-base">Highland Stillhouse #1</div>
              <p class="text-slate-400 leading-relaxed text-[11px]">
                Custom 1,000L Caledonian pot still with copper lyne arm and shell-and-tube condenser.
              </p>
            </div>
          </div>
        </div>

      </div>

      <!-- EQUIPMENT TELEMETRY MATRIX -->
      <div class="bg-[#121824] border border-slate-800 rounded-2xl p-6 space-y-4">
        <h3 class="font-serif-brand text-lg font-bold text-white border-b border-slate-800 pb-3">
          Equipment Asset Telemetry & Maintenance Status
        </h3>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div
            *ngFor="let eq of state.equipment"
            (click)="selectedEquipment = eq"
            class="bg-slate-900/80 border border-slate-800 hover:border-amber-500/50 rounded-xl p-4 space-y-3 cursor-pointer transition-all"
          >
            <div class="flex items-start justify-between">
              <div>
                <span class="text-[10px] font-mono-data text-amber-400 uppercase tracking-wider">{{ eq.type }}</span>
                <h4 class="font-serif-brand font-bold text-white text-sm">{{ eq.name }}</h4>
              </div>
              <span class="px-2 py-0.5 text-[10px] font-mono-data rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                {{ eq.status }}
              </span>
            </div>

            <div class="grid grid-cols-2 gap-2 text-xs font-mono-data pt-2 border-t border-slate-800">
              <div>
                <span class="text-slate-500 block text-[10px]">TEMPERATURE</span>
                <span class="text-amber-300 font-bold text-sm">{{ eq.temperatureC }}°C</span>
              </div>
              <div>
                <span class="text-slate-500 block text-[10px]">PRESSURE</span>
                <span class="text-sky-300 font-bold text-sm">{{ eq.pressureBar }} bar</span>
              </div>
              <div>
                <span class="text-slate-500 block text-[10px]">POWER LOAD</span>
                <span class="text-slate-200 font-bold">{{ eq.powerKw }} kW</span>
              </div>
                <div>
                <span class="text-slate-500 block text-[10px]">ASSET HEALTH</span>
                <span class="text-emerald-400 font-bold">{{ eq.healthPercent }}%</span>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  `,
})
export class DistilleryComponent implements AfterViewInit, OnDestroy {
  @Input() state!: CompanyState;
  @ViewChild('threeCanvas', { static: false }) threeCanvasRef!: ElementRef;

  selectedEquipment?: EquipmentAsset;

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animId?: number;
  private stillMesh!: THREE.Mesh;

  ngAfterViewInit() {
    this.selectedEquipment = this.state.equipment[0];
    this.initThreeJS();
  }

  ngOnDestroy() {
    if (this.animId) cancelAnimationFrame(this.animId);
  }

  private initThreeJS() {
    const container = this.threeCanvasRef.nativeElement;
    const width = container.clientWidth || 600;
    const height = container.clientHeight || 400;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0a0f18);

    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    this.camera.position.set(0, 5, 12);
    this.camera.lookAt(0, 1.5, 0);

    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setSize(width, height);
    container.appendChild(this.renderer.domElement);

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    this.scene.add(ambientLight);

    const pointLight = new THREE.PointLight(0xf59e0b, 2, 20);
    pointLight.position.set(2, 6, 4);
    this.scene.add(pointLight);

    // Build 3D Pot Still Model
    const copperMat = new THREE.MeshStandardMaterial({
      color: 0xb87333,
      metalness: 0.8,
      roughness: 0.3,
    });

    const steelMat = new THREE.MeshStandardMaterial({
      color: 0x94a3b8,
      metalness: 0.9,
      roughness: 0.2,
    });

    // Still pot base
    const potGeo = new THREE.CylinderGeometry(1.5, 2.0, 3, 32);
    this.stillMesh = new THREE.Mesh(potGeo, copperMat);
    this.stillMesh.position.set(-2, 1.5, 0);
    this.scene.add(this.stillMesh);

    // Still neck / swan neck
    const neckGeo = new THREE.CylinderGeometry(0.4, 1.5, 1.5, 32);
    const neckMesh = new THREE.Mesh(neckGeo, copperMat);
    neckMesh.position.set(-2, 3.75, 0);
    this.scene.add(neckMesh);

    // Condenser column (cylinder)
    const condGeo = new THREE.CylinderGeometry(0.8, 0.8, 3.5, 32);
    const condMesh = new THREE.Mesh(condGeo, steelMat);
    condMesh.position.set(2, 2, 0);
    this.scene.add(condMesh);

    // Connecting pipe
    const pipeGeo = new THREE.CylinderGeometry(0.15, 0.15, 4, 16);
    const pipeMesh = new THREE.Mesh(pipeGeo, copperMat);
    pipeMesh.rotation.z = Math.PI / 2;
    pipeMesh.position.set(0, 4.2, 0);
    this.scene.add(pipeMesh);

    // Floor grid
    const grid = new THREE.GridHelper(20, 20, 0x334155, 0x1e293b);
    grid.position.y = 0;
    this.scene.add(grid);

    // Animation loop
    const animate = () => {
      this.animId = requestAnimationFrame(animate);
      if (this.stillMesh) {
        this.stillMesh.rotation.y += 0.005;
        neckMesh.rotation.y += 0.005;
      }
      this.renderer.render(this.scene, this.camera);
    };
    animate();
  }
}
