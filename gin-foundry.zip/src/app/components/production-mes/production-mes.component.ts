import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CompanyState, ProductionBatch } from '../../models/digital-twin.model';

@Component({
  selector: 'app-production-mes',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="space-y-8 pb-12">
      
      <!-- HEADER -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div class="text-xs font-mono-data text-amber-400 mb-1">MODULE 13, 14 & 34 // MANUFACTURING EXECUTION SYSTEM (MES)</div>
          <h1 class="font-serif-brand text-2xl sm:text-3xl font-bold text-white">Production Execution & Batch Scheduler</h1>
          <p class="text-xs text-slate-400 mt-1">
            End-to-end production stage control from raw botanical reservation to distillation, resting, monoblock bottling, and palletizing.
          </p>
        </div>

        <button
          (click)="scheduleBatch.emit('eq-still-01')"
          class="px-4 py-2 text-xs font-semibold rounded-lg bg-amber-600 hover:bg-amber-500 text-white shadow-md transition-all flex items-center gap-1.5"
        >
          <span class="material-icons text-sm">play_arrow</span>
          <span>SCHEDULE NEW 1,000L BATCH</span>
        </button>
      </div>

      <!-- OEE METRICS STRIP -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div class="bg-[#121824] border border-slate-800 rounded-xl p-4 space-y-1">
          <div class="text-[11px] font-mono-data text-slate-400 uppercase">Bottling Line Speed</div>
          <div class="text-2xl font-bold font-mono-data text-white">1,200 btl/hr</div>
          <div class="text-[11px] text-emerald-400 font-mono-data">OEE Index: 88.4%</div>
        </div>

        <div class="bg-[#121824] border border-slate-800 rounded-xl p-4 space-y-1">
          <div class="text-[11px] font-mono-data text-slate-400 uppercase">Reject Rate</div>
          <div class="text-2xl font-bold font-mono-data text-emerald-400">0.42%</div>
          <div class="text-[11px] text-slate-400 font-mono-data">Fill volume variance &lt; 0.5%</div>
        </div>

        <div class="bg-[#121824] border border-slate-800 rounded-xl p-4 space-y-1">
          <div class="text-[11px] font-mono-data text-slate-400 uppercase">Changeover Time</div>
          <div class="text-2xl font-bold font-mono-data text-amber-400">45 Mins</div>
          <div class="text-[11px] text-slate-400 font-mono-data">Rinse & Capper alignment</div>
        </div>

        <div class="bg-[#121824] border border-slate-800 rounded-xl p-4 space-y-1">
          <div class="text-[11px] font-mono-data text-slate-400 uppercase">Active Production Runs</div>
          <div class="text-2xl font-bold font-mono-data text-sky-400">{{ state.batches.length }} Runs</div>
          <div class="text-[11px] text-slate-400 font-mono-data">Batch #2026-0048 Distilling</div>
        </div>
      </div>

      <!-- PRODUCTION BATCH CARDS -->
      <div class="space-y-4">
        <h3 class="font-serif-brand text-xl font-bold text-white border-b border-slate-800 pb-2">
          Batches & Stage Progression
        </h3>

        <div class="space-y-4">
          <div
            *ngFor="let b of state.batches"
            class="bg-[#121824] border border-slate-800 rounded-2xl p-6 space-y-4"
          >
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
              <div>
                <span class="text-xs font-mono-data text-amber-400">BATCH ID: {{ b.batchNumber }}</span>
                <h4 class="font-serif-brand font-bold text-white text-lg">{{ b.productName }} ({{ b.recipeVersion }})</h4>
              </div>

              <div class="flex items-center gap-3 text-xs font-mono-data">
                <span class="px-3 py-1 rounded-full font-bold uppercase bg-amber-500/10 text-amber-400 border border-amber-500/20">
                  STATUS: {{ b.status }}
                </span>
                <span class="text-slate-400">Scheduled: {{ b.scheduledDate }}</span>
              </div>
            </div>

            <!-- Stage Progression Pipeline Bar -->
            <div class="grid grid-cols-2 sm:grid-cols-7 gap-2 text-[10px] font-mono-data">
              <div
                *ngFor="let stage of stages"
                [class.bg-emerald-500/20]="isStageComplete(b.status, stage)"
                [class.text-emerald-300]="isStageComplete(b.status, stage)"
                [class.border-emerald-500/40]="isStageComplete(b.status, stage)"
                [class.bg-amber-500/20]="isStageActive(b.status, stage)"
                [class.text-amber-300]="isStageActive(b.status, stage)"
                [class.border-amber-500/50]="isStageActive(b.status, stage)"
                class="p-2 rounded border border-slate-800 bg-slate-900 text-slate-400 text-center"
              >
                {{ stage }}
              </div>
            </div>

            <!-- Batch Cost & Yield Summary -->
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono-data pt-2 border-t border-slate-800/80">
              <div>
                <span class="text-slate-400 block text-[10px]">RAW MATERIALS COST</span>
                <span class="text-slate-100 font-bold">£{{ b.rawMaterialsCostGbp | number }}</span>
              </div>
              <div>
                <span class="text-slate-400 block text-[10px]">TOTAL BATCH COST</span>
                <span class="text-emerald-400 font-bold">£{{ b.totalBatchCostGbp | number }}</span>
              </div>
              <div>
                <span class="text-slate-400 block text-[10px]">EXPECTED YIELD</span>
                <span class="text-slate-100 font-bold">{{ b.expectedBottles }} bottles</span>
              </div>
              <div>
                <span class="text-slate-400 block text-[10px]">ACTION</span>
                <button
                  *ngIf="b.status !== 'COMPLETED'"
                  (click)="advanceBatch(b.id, b.status)"
                  class="text-amber-400 hover:underline font-bold"
                >
                  Advance Stage →
                </button>
                <span *ngIf="b.status === 'COMPLETED'" class="text-emerald-400">Released to Stock ✓</span>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  `,
})
export class ProductionMesComponent {
  @Input() state!: CompanyState;
  @Output() scheduleBatch = new EventEmitter<string>();
  @Output() updateStatus = new EventEmitter<{ batchId: string; status: ProductionBatch['status'] }>();

  stages: ProductionBatch['status'][] = [
    'PLANNED',
    'MACERATING',
    'DISTILLING',
    'QC_HOLD',
    'DILUTING',
    'BOTTLING',
    'COMPLETED',
  ];

  isStageComplete(current: ProductionBatch['status'], stage: ProductionBatch['status']): boolean {
    return this.stages.indexOf(current) > this.stages.indexOf(stage);
  }

  isStageActive(current: ProductionBatch['status'], stage: ProductionBatch['status']): boolean {
    return current === stage;
  }

  advanceBatch(batchId: string, currentStatus: ProductionBatch['status']) {
    const idx = this.stages.indexOf(currentStatus);
    if (idx >= 0 && idx < this.stages.length - 1) {
      this.updateStatus.emit({ batchId, status: this.stages[idx + 1] });
    }
  }
}
