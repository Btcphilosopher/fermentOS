import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CompanyState, TwinScenario } from '../../models/digital-twin.model';

@Component({
  selector: 'app-scenario-lab',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="space-y-8 pb-12">
      
      <!-- HEADER -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div class="text-xs font-mono-data text-amber-400 mb-1">MODULE 31 // DIGITAL TWIN SCENARIO LAB</div>
          <h1 class="font-serif-brand text-2xl sm:text-3xl font-bold text-white">Scenario Lab & Branch Comparison</h1>
          <p class="text-xs text-slate-400 mt-1">
            Clone company twin states and simulate operational branches (New Stills, Price Changes, Export Expansion, Botanical Shortages).
          </p>
        </div>

        <button
          (click)="saveCurrentScenario()"
          class="px-4 py-2 text-xs font-semibold rounded-lg bg-amber-600 hover:bg-amber-500 text-white shadow-md transition-all flex items-center gap-1.5"
        >
          <span class="material-icons text-sm">content_copy</span>
          <span>SAVE CURRENT STATE AS SCENARIO</span>
        </button>
      </div>

      <!-- SAVED SCENARIO BRANCH CARDS -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div
          *ngFor="let sc of scenarios"
          class="bg-[#121824] border border-slate-800 hover:border-amber-500/50 rounded-2xl p-5 space-y-3 transition-all flex flex-col justify-between"
        >
          <div class="space-y-2">
            <div class="flex items-center justify-between">
              <span class="text-xs font-mono-data text-amber-400 font-bold">⚡ {{ sc.name }}</span>
              <span class="text-[10px] text-slate-500 font-mono-data">{{ sc.createdAt | date:'shortDate' }}</span>
            </div>
            <p class="text-xs text-slate-300 font-sans">{{ sc.description }}</p>
          </div>

          <div class="pt-3 border-t border-slate-800 grid grid-cols-2 gap-2 text-xs font-mono-data">
            <div>
              <span class="text-slate-500 block text-[10px]">VALUATION</span>
              <span class="text-white font-bold">£{{ sc.state.financials.companyValuationGbp | number:'1.0-0' }}</span>
            </div>
            <div>
              <span class="text-slate-500 block text-[10px]">UNIT COST</span>
              <span class="text-emerald-400 font-bold">£{{ sc.state.financials.costPerBottleGbp }}</span>
            </div>
            <div>
              <span class="text-slate-500 block text-[10px]">CASH RUNWAY</span>
              <span class="text-amber-300 font-bold">{{ sc.state.financials.runwayMonths }} mo</span>
            </div>
            <div>
              <span class="text-slate-500 block text-[10px]">CAPACITY</span>
              <span class="text-slate-200 font-bold">{{ sc.state.financials.capacityUtilisationPercent }}%</span>
            </div>
          </div>

          <button
            (click)="loadScenario.emit(sc.id)"
            class="w-full mt-2 py-2 text-xs font-bold font-mono-data bg-slate-900 hover:bg-amber-600/20 text-amber-300 border border-slate-700 hover:border-amber-500 rounded-lg transition-colors"
          >
            RESTORE THIS SCENARIO →
          </button>
        </div>
      </div>

    </div>
  `,
})
export class ScenarioLabComponent {
  @Input() state!: CompanyState;
  @Input() scenarios: TwinScenario[] = [];

  @Output() saveScenario = new EventEmitter<{ name: string; description: string }>();
  @Output() loadScenario = new EventEmitter<string>();

  saveCurrentScenario() {
    const name = prompt('Enter Scenario Name:', 'Export Growth Case');
    const description = prompt('Enter Brief Description:', 'Simulates 2x volume expansion with £185k Capex still.');
    if (name && description) {
      this.saveScenario.emit({ name, description });
    }
  }
}
