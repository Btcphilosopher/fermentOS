import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CompanyState, PackagingSpecification } from '../../models/digital-twin.model';

@Component({
  selector: 'app-packaging',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="space-y-8 pb-12">
      
      <!-- HEADER -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div class="text-xs font-mono-data text-amber-400 mb-1">MODULE 15 & 16 // PACKAGING STUDIO & LOGISTICS MODEL</div>
          <h1 class="font-serif-brand text-2xl sm:text-3xl font-bold text-white">Packaging Studio & Pallet Geometry</h1>
          <p class="text-xs text-slate-400 mt-1">
            Modifying bottle weight, closure type, or carton configuration recalculates freight costs, warehouse footprint, and unit COGS.
          </p>
        </div>

        <button
          (click)="savePackaging()"
          class="px-4 py-2 text-xs font-semibold rounded-lg bg-amber-600 hover:bg-amber-500 text-white shadow-md transition-all flex items-center gap-1.5"
        >
          <span class="material-icons text-sm">save</span>
          <span>SAVE PACKAGING SPECIFICATION</span>
        </button>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        <!-- PACKAGING COMPONENTS EDITOR (7 cols) -->
        <div class="lg:col-span-7 bg-[#121824] border border-slate-800 rounded-2xl p-6 space-y-6">
          <h3 class="font-serif-brand text-lg font-bold text-white border-b border-slate-800 pb-3">
            Primary & Secondary Packaging Bill of Materials
          </h3>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            
            <div class="space-y-1">
              <label class="font-medium text-slate-300">Glass Bottle Type</label>
              <input
                type="text"
                [(ngModel)]="tempPackaging.bottleType"
                class="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100 outline-none"
              />
            </div>

            <div class="space-y-1">
              <label class="font-medium text-slate-300">Bottle Unit Cost (£)</label>
              <input
                type="number"
                step="0.05"
                [(ngModel)]="tempPackaging.bottleUnitCostGbp"
                class="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100 font-mono-data outline-none"
              />
            </div>

            <div class="space-y-1">
              <label class="font-medium text-slate-300">Closure Type</label>
              <input
                type="text"
                [(ngModel)]="tempPackaging.closureType"
                class="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100 outline-none"
              />
            </div>

            <div class="space-y-1">
              <label class="font-medium text-slate-300">Closure Unit Cost (£)</label>
              <input
                type="number"
                step="0.02"
                [(ngModel)]="tempPackaging.closureUnitCostGbp"
                class="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100 font-mono-data outline-none"
              />
            </div>

            <div class="space-y-1">
              <label class="font-medium text-slate-300">Label Specification</label>
              <input
                type="text"
                [(ngModel)]="tempPackaging.labelType"
                class="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100 outline-none"
              />
            </div>

            <div class="space-y-1">
              <label class="font-medium text-slate-300">Label Unit Cost (£)</label>
              <input
                type="number"
                step="0.02"
                [(ngModel)]="tempPackaging.labelUnitCostGbp"
                class="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100 font-mono-data outline-none"
              />
            </div>

            <div class="space-y-1">
              <label class="font-medium text-slate-300">Carton Size (Bottles per Case)</label>
              <select
                [(ngModel)]="tempPackaging.cartonSizeBottles"
                class="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100 font-mono-data outline-none"
              >
                <option [ngValue]="6">6 Bottles per Case (Standard)</option>
                <option [ngValue]="12">12 Bottles per Case (Bulk)</option>
              </select>
            </div>

            <div class="space-y-1">
              <label class="font-medium text-slate-300">Carton Unit Cost (£)</label>
              <input
                type="number"
                step="0.10"
                [(ngModel)]="tempPackaging.cartonUnitCostGbp"
                class="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100 font-mono-data outline-none"
              />
            </div>

          </div>
        </div>

        <!-- PALLET GEOMETRY & LOGISTICS SUMMARY (5 cols) -->
        <div class="lg:col-span-5 space-y-6">
          <div class="bg-[#121824] border border-slate-800 rounded-2xl p-6 space-y-4">
            <h3 class="font-serif-brand text-lg font-bold text-white border-b border-slate-800 pb-3">
              Palletization & Freight Calculator
            </h3>

            <div class="space-y-3 text-xs font-mono-data">
              <div class="p-3 rounded-lg bg-slate-900 border border-slate-800 flex justify-between">
                <span class="text-slate-400">Total Packaging Cost / Btl:</span>
                <span class="text-emerald-400 font-bold text-sm">
                  £{{ (tempPackaging.bottleUnitCostGbp + tempPackaging.closureUnitCostGbp + tempPackaging.labelUnitCostGbp + tempPackaging.cartonUnitCostGbp / tempPackaging.cartonSizeBottles) | number:'1.2-2' }}
                </span>
              </div>

              <div class="p-3 rounded-lg bg-slate-900 border border-slate-800 flex justify-between">
                <span class="text-slate-400">Pallet Capacity:</span>
                <span class="text-amber-300 font-bold">
                  {{ tempPackaging.palletCapacityCases }} cases ({{ tempPackaging.palletCapacityCases * tempPackaging.cartonSizeBottles }} btl)
                </span>
              </div>

              <div class="p-3 rounded-lg bg-slate-900 border border-slate-800 flex justify-between">
                <span class="text-slate-400">Freight Cost / Pallet:</span>
                <span class="text-slate-200 font-bold">
                  £{{ tempPackaging.freightCostPerPalletGbp }} (£{{ (tempPackaging.freightCostPerPalletGbp / (tempPackaging.palletCapacityCases * tempPackaging.cartonSizeBottles)) | number:'1.2-2' }}/btl)
                </span>
              </div>

              <div class="p-3 rounded-lg bg-slate-900 border border-slate-800 flex justify-between">
                <span class="text-slate-400">Recyclability Rating:</span>
                <span class="text-emerald-400 font-bold">{{ tempPackaging.recyclabilityPercent }}%</span>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>
  `,
})
export class PackagingComponent implements OnInit {
  @Input() state!: CompanyState;
  @Output() updatePackaging = new EventEmitter<Partial<PackagingSpecification>>();

  tempPackaging!: PackagingSpecification;

  ngOnInit() {
    this.tempPackaging = JSON.parse(JSON.stringify(this.state.packaging));
  }

  savePackaging() {
    this.updatePackaging.emit(this.tempPackaging);
  }
}
