import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CompanyState } from '../../models/digital-twin.model';

@Component({
  selector: 'app-scale-up-wizard',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div *ngIf="isOpen" class="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div class="bg-[#121824] border border-amber-500/40 rounded-2xl max-w-2xl w-full p-6 space-y-6 shadow-2xl">
        
        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
          <div class="flex items-center gap-2">
            <span class="material-icons text-amber-400">trending_up</span>
            <h3 class="font-serif-brand font-bold text-white text-lg">SCALE-UP WIZARD — TAKE THIS GIN TO 1 MILLION BOTTLES</h3>
          </div>
          <button (click)="closeWizard.emit()" class="text-slate-400 hover:text-white">✕</button>
        </div>

        <div class="space-y-4 text-xs font-mono-data">
          
          <div class="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
            <div class="text-amber-400 font-bold uppercase">BOTTLENECK ANALYSIS & REQUIRED CAPEX</div>
            
            <div class="grid grid-cols-2 gap-3 pt-2 text-slate-300">
              <div>
                <span class="text-slate-500 block">Current Capacity:</span>
                <span class="font-bold text-white">{{ state.financials.annualProductionCapacityBottles | number }} btl/yr</span>
              </div>
              <div>
                <span class="text-slate-500 block">Scale Target:</span>
                <span class="font-bold text-amber-400">1,000,000 btl/yr (18.1x expansion)</span>
              </div>
              <div>
                <span class="text-slate-500 block">Primary Capex Required:</span>
                <span class="font-bold text-emerald-400">£1,450,000</span>
              </div>
              <div>
                <span class="text-slate-500 block">Working Capital Need:</span>
                <span class="font-bold text-sky-400">£820,000</span>
              </div>
            </div>
          </div>

          <div class="space-y-2">
            <div class="text-slate-300 font-bold uppercase text-[11px]">Recommended Expansion Roadmap:</div>

            <div class="space-y-2 text-slate-300 font-sans">
              <div class="p-3 rounded-lg bg-slate-900/60 border border-slate-800 space-y-1">
                <div class="font-bold text-amber-300 text-xs">1. Install 2x 5,000L Automated Copper Column Hybrid Stills</div>
                <div class="text-[11px] text-slate-400">Replaces 1,000L pot still. Increases single batch yield from 1,250 to 6,250 bottles per run.</div>
              </div>

              <div class="p-3 rounded-lg bg-slate-900/60 border border-slate-800 space-y-1">
                <div class="font-bold text-sky-300 text-xs">2. Upgrade High-Speed Monoblock Bottling & Capping Line</div>
                <div class="text-[11px] text-slate-400">Increases bottling speed from 1,200 to 6,000 bottles/hour with automated laser coding and case packing.</div>
              </div>

              <div class="p-3 rounded-lg bg-slate-900/60 border border-slate-800 space-y-1">
                <div class="font-bold text-emerald-300 text-xs">3. Long-Term Botanical Supply Contracts</div>
                <div class="text-[11px] text-slate-400">Locks in 22 tonnes/year of Caledonian juniper with 18-month fixed supplier pricing guarantee.</div>
              </div>
            </div>
          </div>

        </div>

        <div class="flex justify-end gap-3 pt-3 border-t border-slate-800">
          <button (click)="closeWizard.emit()" class="px-4 py-2 text-xs text-slate-400 hover:text-white">Close</button>
          <button
            (click)="applyScaleUp()"
            class="px-5 py-2 text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg shadow-lg"
          >
            APPLY 1M SCALE-UP SCENARIO TO DIGITAL TWIN
          </button>
        </div>

      </div>
    </div>
  `,
})
export class ScaleUpWizardComponent {
  @Input() isOpen = false;
  @Input() state!: CompanyState;
  @Output() closeWizard = new EventEmitter<void>();
  @Output() applyScale = new EventEmitter<void>();

  applyScaleUp() {
    this.applyScale.emit();
    this.closeWizard.emit();
  }
}
