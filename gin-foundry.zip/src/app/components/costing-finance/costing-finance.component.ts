import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CompanyState } from '../../models/digital-twin.model';

@Component({
  selector: 'app-costing-finance',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="space-y-8 pb-12">
      
      <!-- HEADER -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div class="text-xs font-mono-data text-amber-400 mb-1">MODULE 17, 18 & 19 // MANUFACTURING COSTING ENGINE & FINANCIAL MODEL</div>
          <h1 class="font-serif-brand text-2xl sm:text-3xl font-bold text-white">Costing Engine & Financial Simulator</h1>
          <p class="text-xs text-slate-400 mt-1">
            Explicit, unhidden manufacturing cost breakdown per bottle and 60-month cash flow forecast.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <span class="text-xs font-mono-data text-emerald-400 font-bold bg-emerald-500/10 border border-emerald-500/20 px-3 py-1.5 rounded">
            EBITDA: £{{ state.financials.ebitdaGbp | number }}
          </span>
        </div>
      </div>

      <!-- UNIT COGS DETAILED BREAKDOWN -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        <!-- COST BREAKDOWN CHART & PIECES (7 cols) -->
        <div class="lg:col-span-7 bg-[#121824] border border-slate-800 rounded-2xl p-6 space-y-6">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 class="font-serif-brand text-lg font-bold text-white">Manufacturing Cost per Bottle (700ml)</h3>
              <p class="text-xs text-slate-400">Calculated from 1,000L batch run yielding ~1,250 bottles at {{ state.product.abvPercent }}% ABV.</p>
            </div>
            <span class="text-xl font-bold font-mono-data text-emerald-400">
              £{{ state.financials.costPerBottleGbp | number:'1.2-2' }}
            </span>
          </div>

          <div class="space-y-3 font-mono-data text-xs">
            
            <div class="space-y-1">
              <div class="flex justify-between">
                <span class="text-slate-300">Organic Wheat Spirit Base:</span>
                <span class="text-white font-bold">£1.68 / btl</span>
              </div>
              <div class="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden">
                <div class="bg-amber-500 h-full" style="width: 30%"></div>
              </div>
            </div>

            <div class="space-y-1">
              <div class="flex justify-between">
                <span class="text-slate-300">Botanicals (Juniper, Heather, Sea Buckthorn):</span>
                <span class="text-white font-bold">£0.32 / btl</span>
              </div>
              <div class="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden">
                <div class="bg-emerald-500 h-full" style="width: 8%"></div>
              </div>
            </div>

            <div class="space-y-1">
              <div class="flex justify-between">
                <span class="text-slate-300">Primary Packaging (Bottle, Cork, Label):</span>
                <span class="text-white font-bold">£3.45 / btl</span>
              </div>
              <div class="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden">
                <div class="bg-sky-500 h-full" style="width: 50%"></div>
              </div>
            </div>

            <div class="space-y-1">
              <div class="flex justify-between">
                <span class="text-slate-300">Distillation Utilities & Energy (0.38 kWh):</span>
                <span class="text-white font-bold">£0.14 / btl</span>
              </div>
              <div class="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden">
                <div class="bg-purple-500 h-full" style="width: 3%"></div>
              </div>
            </div>

            <div class="space-y-1">
              <div class="flex justify-between">
                <span class="text-slate-300">Direct Distiller Labour:</span>
                <span class="text-white font-bold">£0.20 / btl</span>
              </div>
              <div class="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden">
                <div class="bg-rose-500 h-full" style="width: 4%"></div>
              </div>
            </div>

            <div class="space-y-1">
              <div class="flex justify-between">
                <span class="text-slate-300">Distillery Overhead Allocation:</span>
                <span class="text-white font-bold">£0.26 / btl</span>
              </div>
              <div class="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden">
                <div class="bg-yellow-500 h-full" style="width: 5%"></div>
              </div>
            </div>

          </div>
        </div>

        <!-- WHOLESALE & RETAIL MARGIN ANALYSIS (5 cols) -->
        <div class="lg:col-span-5 bg-[#121824] border border-slate-800 rounded-2xl p-6 space-y-6">
          <h3 class="font-serif-brand text-lg font-bold text-white border-b border-slate-800 pb-3">
            Pricing Waterfall & Contribution
          </h3>

          <div class="space-y-4 text-xs font-mono-data">
            <div class="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex justify-between">
              <span class="text-slate-400">Target Retail Price (RRP inc. VAT):</span>
              <span class="text-white font-bold text-sm">£{{ state.product.targetRetailPriceGbp }}</span>
            </div>

            <div class="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex justify-between">
              <span class="text-slate-400">UK Excise Duty Placeholder (700ml 43%):</span>
              <span class="text-amber-400 font-bold">~£9.52 / btl</span>
            </div>

            <div class="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex justify-between">
              <span class="text-slate-400">Target Wholesale Price (ex VAT):</span>
              <span class="text-sky-400 font-bold text-sm">£{{ state.product.targetWholesalePriceGbp }}</span>
            </div>

            <div class="p-3.5 rounded-xl bg-emerald-950/30 border border-emerald-500/30 flex justify-between">
              <span class="text-emerald-300 font-bold">Gross Margin %:</span>
              <span class="text-emerald-400 font-bold text-base">{{ state.financials.grossMarginPercent }}%</span>
            </div>
          </div>
        </div>

      </div>

      <!-- 60-MONTH FINANCIAL MODEL TABLE -->
      <div class="bg-[#121824] border border-slate-800 rounded-2xl p-6 space-y-4">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 class="font-serif-brand text-lg font-bold text-white">60-Month Start-up Financial Projection</h3>
            <p class="text-xs text-slate-400">Modelled revenue growth, capacity utilization, and cash balance.</p>
          </div>
          <span class="text-xs font-mono-data text-amber-400">5-YEAR PROJECTION</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs font-mono-data">
            <thead>
              <tr class="text-slate-400 border-b border-slate-800 uppercase text-[10px]">
                <th class="py-2.5 px-3">Metric</th>
                <th class="py-2.5 px-3">Year 1</th>
                <th class="py-2.5 px-3">Year 2</th>
                <th class="py-2.5 px-3">Year 3</th>
                <th class="py-2.5 px-3">Year 4</th>
                <th class="py-2.5 px-3">Year 5</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 text-slate-200">
              <tr>
                <td class="py-3 px-3 font-bold text-slate-100">Bottles Produced</td>
                <td class="py-3 px-3">15,000</td>
                <td class="py-3 px-3">45,000</td>
                <td class="py-3 px-3">120,000</td>
                <td class="py-3 px-3">350,000</td>
                <td class="py-3 px-3 text-amber-400 font-bold">1,000,000</td>
              </tr>
              <tr>
                <td class="py-3 px-3 font-bold text-slate-100">Revenue (£)</td>
                <td class="py-3 px-3">£367,500</td>
                <td class="py-3 px-3">£1,102,500</td>
                <td class="py-3 px-3">£2,940,000</td>
                <td class="py-3 px-3">£8,575,000</td>
                <td class="py-3 px-3 text-emerald-400 font-bold">£24,500,000</td>
              </tr>
              <tr>
                <td class="py-3 px-3 font-bold text-slate-100">Gross COGS (£)</td>
                <td class="py-3 px-3">£82,200</td>
                <td class="py-3 px-3">£246,600</td>
                <td class="py-3 px-3">£657,600</td>
                <td class="py-3 px-3">£1,918,000</td>
                <td class="py-3 px-3 text-slate-300">£5,480,000</td>
              </tr>
              <tr>
                <td class="py-3 px-3 font-bold text-slate-100">EBITDA (£)</td>
                <td class="py-3 px-3 text-amber-300">£142,000</td>
                <td class="py-3 px-3 text-amber-300">£485,000</td>
                <td class="py-3 px-3 text-amber-300">£1,350,000</td>
                <td class="py-3 px-3 text-amber-300">£4,120,000</td>
                <td class="py-3 px-3 text-amber-400 font-bold">£12,200,000</td>
              </tr>
              <tr>
                <td class="py-3 px-3 font-bold text-slate-100">End Cash Balance (£)</td>
                <td class="py-3 px-3 font-bold text-emerald-400">£215,000</td>
                <td class="py-3 px-3 font-bold text-emerald-400">£540,000</td>
                <td class="py-3 px-3 font-bold text-emerald-400">£1,680,000</td>
                <td class="py-3 px-3 font-bold text-emerald-400">£4,950,000</td>
                <td class="py-3 px-3 font-bold text-emerald-400">£14,200,000</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  `,
})
export class CostingFinanceComponent {
  @Input() state!: CompanyState;
}
