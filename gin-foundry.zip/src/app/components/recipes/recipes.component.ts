import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Botanical, CompanyState, RecipeVersion } from '../../models/digital-twin.model';

@Component({
  selector: 'app-recipes',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="space-y-8 pb-12">
      
      <!-- HEADER -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div class="text-xs font-mono-data text-amber-400 mb-1">MODULE 03 // RECIPE ENGINE & VERSION CONTROL</div>
          <h1 class="font-serif-brand text-2xl sm:text-3xl font-bold text-white">Recipe Formulation & Audit System</h1>
          <p class="text-xs text-slate-400 mt-1">
            Auditable version control. Modifying botanical dosages immediately recalculates batch cost, expected bottle yield, and flavour vector.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <!-- Recipe Version Selector -->
          <div class="flex items-center gap-2 bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs font-mono-data">
            <span class="text-slate-400">ACTIVE VERSION:</span>
            <span class="text-amber-400 font-bold">{{ activeRecipe.version }}</span>
            <span class="text-slate-500">({{ activeRecipe.status }})</span>
          </div>
        </div>
      </div>

      <!-- RECIPE TOP SUMMARY CARDS -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
        
        <div class="bg-[#121824] border border-slate-800 rounded-xl p-4 space-y-1">
          <div class="text-[11px] font-medium text-slate-400 uppercase tracking-wider font-mono-data">Base Spirit Volume</div>
          <div class="text-2xl font-bold font-mono-data text-white">{{ activeRecipe.baseSpiritVolumeL | number }} L</div>
          <div class="text-[11px] text-slate-400 font-mono-data">{{ activeRecipe.baseSpiritType }}</div>
        </div>

        <div class="bg-[#121824] border border-slate-800 rounded-xl p-4 space-y-1">
          <div class="text-[11px] font-medium text-slate-400 uppercase tracking-wider font-mono-data">Total Botanical Load</div>
          <div class="text-2xl font-bold font-mono-data text-amber-400">{{ totalBotanicalWeightKg | number:'1.2-2' }} kg</div>
          <div class="text-[11px] text-slate-400 font-mono-data">{{ activeRecipe.botanicals.length }} botanical ingredients</div>
        </div>

        <div class="bg-[#121824] border border-slate-800 rounded-xl p-4 space-y-1">
          <div class="text-[11px] font-medium text-slate-400 uppercase tracking-wider font-mono-data">Hearts Yield Forecast</div>
          <div class="text-2xl font-bold font-mono-data text-emerald-400">~{{ expectedBottles | number }} btl</div>
          <div class="text-[11px] text-slate-400 font-mono-data">At {{ state.product.abvPercent }}% ABV target</div>
        </div>

        <div class="bg-[#121824] border border-slate-800 rounded-xl p-4 space-y-1">
          <div class="text-[11px] font-medium text-slate-400 uppercase tracking-wider font-mono-data">Estimated COGS / Btl</div>
          <div class="text-2xl font-bold font-mono-data text-purple-400">£{{ state.financials.costPerBottleGbp | number:'1.2-2' }}</div>
          <div class="text-[11px] text-slate-400 font-mono-data">Gross Margin: {{ state.financials.grossMarginPercent }}%</div>
        </div>

      </div>

      <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        <!-- BOTANICAL DOSAGE TABLE & SLIDERS (8 cols) -->
        <div class="lg:col-span-8 bg-[#121824] border border-slate-800 rounded-2xl p-6 space-y-6">
          <div class="flex items-center justify-between border-b border-slate-800 pb-4">
            <div>
              <h3 class="font-serif-brand text-lg font-bold text-white">Botanical Dosage Formulation</h3>
              <p class="text-xs text-slate-400">Dosage measured in grams per Litre of base spirit at {{ activeRecipe.baseSpiritABV }}% ABV.</p>
            </div>

            <!-- Add Botanical to Recipe Dropdown -->
            <div class="relative">
              <select
                (change)="addBotanicalToRecipe($event)"
                class="bg-slate-900 border border-amber-500/40 text-amber-300 text-xs rounded-lg px-3 py-1.5 font-mono-data outline-none"
              >
                <option value="">+ Add Botanical to Formula</option>
                <option *ngFor="let b of availableBotanicals" [value]="b.id">
                  {{ b.commonName }} (£{{ b.pricePerKg }}/kg)
                </option>
              </select>
            </div>
          </div>

          <!-- Dosage Table -->
          <div class="space-y-4">
            <div
              *ngFor="let dos of activeRecipe.botanicals"
              class="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-3"
            >
              <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <span class="font-bold text-slate-100 text-sm">{{ dos.botanicalName }}</span>
                  <span class="text-xs text-slate-400 font-mono-data ml-2">
                    ({{ getBotanicalPrice(dos.botanicalId) | currency:'GBP':'symbol':'1.2-2' }}/kg)
                  </span>
                </div>

                <div class="flex items-center gap-4 text-xs font-mono-data">
                  <div>
                    <span class="text-slate-400">Batch Mass: </span>
                    <span class="text-amber-300 font-bold">
                      {{ ((dos.gramsPerLitreBaseSpirit * activeRecipe.baseSpiritVolumeL) / 1000) | number:'1.2-2' }} kg
                    </span>
                  </div>
                  <div>
                    <span class="text-slate-400">Dosage: </span>
                    <span class="text-emerald-400 font-bold text-sm">{{ dos.gramsPerLitreBaseSpirit }} g/L</span>
                  </div>
                </div>
              </div>

              <!-- Dosage Slider -->
              <div class="space-y-1">
                <input
                  type="range"
                  min="0.5"
                  max="50"
                  step="0.5"
                  [ngModel]="dos.gramsPerLitreBaseSpirit"
                  (ngModelChange)="onDosageSliderChange(dos.botanicalId, $event)"
                  class="w-full accent-amber-500 bg-slate-800"
                />
                <div class="flex justify-between text-[10px] font-mono-data text-slate-500">
                  <span>0.5 g/L</span>
                  <span>Recommended: {{ getRecommendedRange(dos.botanicalId) }}</span>
                  <span>50 g/L</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- PROCESS PARAMETERS & FLAVOUR RADAR SUMMARY (4 cols) -->
        <div class="lg:col-span-4 space-y-6">
          
          <!-- Distillation Cuts & Process Parameters -->
          <div class="bg-[#121824] border border-slate-800 rounded-2xl p-6 space-y-4">
            <h3 class="font-serif-brand text-base font-bold text-white border-b border-slate-800 pb-3">
              Distillation & Cut Parameters
            </h3>

            <div class="space-y-4 text-xs">
              <div class="space-y-1">
                <label class="text-slate-300 font-medium">Distillation Method</label>
                <select
                  [(ngModel)]="activeRecipe.distillationMethod"
                  class="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-200 font-mono-data outline-none"
                >
                  <option value="POT_STILL">Copper Pot Still (Direct Maceration)</option>
                  <option value="COLUMN_HYBRID">Hybrid Column Still</option>
                  <option value="VAPOUR_INFUSION">Carter-Head Vapour Infusion Basket</option>
                </select>
              </div>

              <div class="space-y-1">
                <div class="flex justify-between text-slate-300">
                  <span>Heads Cut Target</span>
                  <span class="font-mono-data text-amber-400 font-bold">{{ activeRecipe.headsCutPercent }}%</span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="5.0"
                  step="0.1"
                  [(ngModel)]="activeRecipe.headsCutPercent"
                  class="w-full accent-amber-500 bg-slate-800"
                />
              </div>

              <div class="space-y-1">
                <div class="flex justify-between text-slate-300">
                  <span>Tails Cut Target</span>
                  <span class="font-mono-data text-amber-400 font-bold">{{ activeRecipe.tailsCutPercent }}%</span>
                </div>
                <input
                  type="range"
                  min="5.0"
                  max="25.0"
                  step="0.5"
                  [(ngModel)]="activeRecipe.tailsCutPercent"
                  class="w-full accent-amber-500 bg-slate-800"
                />
              </div>

              <div class="space-y-1">
                <div class="flex justify-between text-slate-300">
                  <span>Resting Period</span>
                  <span class="font-mono-data text-sky-400 font-bold">{{ activeRecipe.restingDays }} Days</span>
                </div>
                <input
                  type="range"
                  min="3"
                  max="30"
                  step="1"
                  [(ngModel)]="activeRecipe.restingDays"
                  class="w-full accent-sky-500 bg-slate-800"
                />
              </div>
            </div>
          </div>

          <!-- Recipe Version Audit Log -->
          <div class="bg-[#121824] border border-slate-800 rounded-2xl p-6 space-y-3">
            <h3 class="font-serif-brand text-base font-bold text-white border-b border-slate-800 pb-2">
              Recipe Version Audit Trail
            </h3>

            <div class="space-y-3 text-xs font-mono-data">
              <div
                *ngFor="let ver of state.product.recipeHistory"
                class="bg-slate-900/60 p-3 rounded-lg border border-slate-800 space-y-1"
              >
                <div class="flex justify-between text-amber-300 font-bold">
                  <span>{{ ver.version }} — {{ ver.label }}</span>
                  <span class="text-[10px] text-slate-400">{{ ver.createdAt }}</span>
                </div>
                <p class="text-slate-300 text-[11px] font-sans">{{ ver.notes }}</p>
                <div class="text-[10px] text-slate-500">Author: {{ ver.author }}</div>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  `,
})
export class RecipesComponent {
  @Input() state!: CompanyState;
  @Output() updateDosage = new EventEmitter<{ botanicalId: string; gramsPerLitre: number }>();

  get activeRecipe(): RecipeVersion {
    const prod = this.state.product;
    return prod.recipeHistory.find((r) => r.version === prod.activeRecipeVersion) || prod.recipeHistory[0];
  }

  get totalBotanicalWeightKg(): number {
    const baseL = this.activeRecipe.baseSpiritVolumeL;
    return this.activeRecipe.botanicals.reduce((sum, b) => sum + (b.gramsPerLitreBaseSpirit * baseL) / 1000, 0);
  }

  get expectedBottles(): number {
    const activeRecipe = this.activeRecipe;
    const baseSpiritL = activeRecipe.baseSpiritVolumeL;
    const pureAlcInput = baseSpiritL * (activeRecipe.baseSpiritABV / 100.0);
    const heartsRecovery = 1.0 - (activeRecipe.headsCutPercent + activeRecipe.tailsCutPercent) / 100.0;
    const heartsPureAlc = pureAlcInput * heartsRecovery;
    const dilutedGinVolumeL = heartsPureAlc / (this.state.product.abvPercent / 100.0);
    return Math.floor(dilutedGinVolumeL / (this.state.product.bottleVolumeMl / 1000.0));
  }

  get availableBotanicals(): Botanical[] {
    const activeIds = this.activeRecipe.botanicals.map((b) => b.botanicalId);
    return this.state.botanicals.filter((b) => !activeIds.includes(b.id));
  }

  getBotanicalPrice(botanicalId: string): number {
    const b = this.state.botanicals.find((bot) => bot.id === botanicalId);
    return b ? b.pricePerKg : 20.0;
  }

  getRecommendedRange(botanicalId: string): string {
    const b = this.state.botanicals.find((bot) => bot.id === botanicalId);
    if (!b) return '5 - 20 g/L';
    return `${b.recommendedDosageRange.minGramsPerLitre} - ${b.recommendedDosageRange.maxGramsPerLitre} g/L`;
  }

  onDosageSliderChange(botanicalId: string, gramsPerLitre: number) {
    this.updateDosage.emit({ botanicalId, gramsPerLitre });
  }

  addBotanicalToRecipe(event: Event) {
    const target = event.target as HTMLSelectElement;
    if (!target || !target.value) return;
    const botanicalId = target.value;
    this.updateDosage.emit({ botanicalId, gramsPerLitre: 5.0 });
  }
}
