import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CompanyState, EventLogItem } from '../../models/digital-twin.model';

@Component({
  selector: 'app-overview',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="space-y-8 pb-12">
      
      <!-- HERO STRIP & COMPANY IDENTIFIER -->
      <div class="relative overflow-hidden rounded-2xl bg-gradient-to-r from-slate-900 via-[#161f30] to-slate-900 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div class="absolute -right-12 -top-12 w-96 h-96 bg-amber-600/10 rounded-full blur-3xl pointer-events-none"></div>
        
        <div class="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <div class="flex items-center gap-2 text-xs font-mono-data text-amber-400 mb-2">
              <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span>LIVE DIGITAL TWIN ACTIVE</span>
              <span>·</span>
              <span>{{ state.companyName }}</span>
              <span>·</span>
              <span>EST. {{ state.foundingYear }}</span>
            </div>
            <h1 class="font-serif-brand text-3xl sm:text-4xl font-bold tracking-tight text-white">
              Start-up Command Centre
            </h1>
            <p class="text-slate-400 text-sm max-w-2xl mt-1">
              Connected digital twin model propagating changes from botanical recipe formulation directly to factory floor execution, bottle COGS, and 60-month cash flow.
            </p>
          </div>

          <!-- Quick Action Buttons -->
          <div class="flex flex-wrap items-center gap-3">
            <button
              (click)="openFounderWizard.emit()"
              class="px-4 py-2 text-xs font-semibold rounded-lg bg-amber-600 hover:bg-amber-500 text-white shadow-lg transition-all flex items-center gap-2"
            >
              <span class="material-icons text-sm">auto_awesome</span>
              <span>BUILD MY GIN</span>
            </button>

            <button
              (click)="openScaleUpWizard.emit()"
              class="px-4 py-2 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 transition-all flex items-center gap-2"
            >
              <span class="material-icons text-sm">trending_up</span>
              <span>SCALE TO 1M BOTTLES</span>
            </button>
          </div>
        </div>
      </div>

      <!-- TOP-LEVEL EXECUTIVE KPIS -->
      <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
        
        <div class="bg-[#121824] border border-slate-800 rounded-xl p-4 space-y-1">
          <div class="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Company Valuation</div>
          <div class="text-2xl font-bold font-mono-data text-white">£{{ state.financials.companyValuationGbp | number:'1.0-0' }}</div>
          <div class="text-[11px] text-emerald-400 flex items-center gap-1 font-mono-data">
            <span>↑ 18.4% YoY</span>
          </div>
        </div>

        <div class="bg-[#121824] border border-slate-800 rounded-xl p-4 space-y-1">
          <div class="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Cash Balance</div>
          <div class="text-2xl font-bold font-mono-data text-amber-400">£{{ state.financials.cashBalanceGbp | number:'1.0-0' }}</div>
          <div class="text-[11px] text-slate-400 font-mono-data">
            <span>Runway: {{ state.financials.runwayMonths }} months</span>
          </div>
        </div>

        <div class="bg-[#121824] border border-slate-800 rounded-xl p-4 space-y-1">
          <div class="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Unit Cost / Bottle</div>
          <div class="text-2xl font-bold font-mono-data text-emerald-400">£{{ state.financials.costPerBottleGbp | number:'1.2-2' }}</div>
          <div class="text-[11px] text-slate-400 font-mono-data">
            <span>COGS Margin: {{ state.financials.grossMarginPercent }}%</span>
          </div>
        </div>

        <div class="bg-[#121824] border border-slate-800 rounded-xl p-4 space-y-1">
          <div class="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Current Inventory</div>
          <div class="text-2xl font-bold font-mono-data text-white">{{ state.financials.currentInventoryBottles | number }}</div>
          <div class="text-[11px] text-slate-400 font-mono-data">
            <span>Wholesale Price: £{{ state.product.targetWholesalePriceGbp }}</span>
          </div>
        </div>

        <div class="bg-[#121824] border border-slate-800 rounded-xl p-4 space-y-1">
          <div class="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Capacity Utilisation</div>
          <div class="text-2xl font-bold font-mono-data text-sky-400">{{ state.financials.capacityUtilisationPercent }}%</div>
          <div class="text-[11px] text-slate-400 font-mono-data">
            <span>Max: {{ state.financials.annualProductionCapacityBottles | number }} btl/yr</span>
          </div>
        </div>

      </div>

      <!-- MAIN FEATURE SECTION: COMPANY AS A SYSTEM CAUSAL DIAGRAM -->
      <div class="bg-[#121824] border border-slate-800 rounded-2xl p-6 space-y-6">
        <div class="flex items-center justify-between">
          <div>
            <h2 class="font-serif-brand text-xl font-bold text-white">Company as a System — Digital Twin Causal Graph</h2>
            <p class="text-xs text-slate-400">Live dependencies linking recipe inputs directly to manufacturing, unit economics, and enterprise value.</p>
          </div>
          <span class="text-xs font-mono-data px-2.5 py-1 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">AUTONOMOUS RECALCULATION</span>
        </div>

        <!-- Causal Flow Nodes -->
        <div class="grid grid-cols-1 md:grid-cols-5 gap-3 relative">
          
          <!-- Node 1: Product & Recipe -->
          <div (click)="navigateTo.emit('recipes')" class="bg-slate-900/80 border border-amber-500/30 hover:border-amber-500 rounded-xl p-4 cursor-pointer transition-all hover:scale-[1.02] group">
            <div class="text-xs font-mono-data text-amber-400 mb-1 flex items-center justify-between">
              <span>01. PRODUCT & RECIPE</span>
              <span class="group-hover:translate-x-1 transition-transform">→</span>
            </div>
            <div class="font-bold text-slate-100 text-sm">{{ state.product.name }}</div>
            <div class="text-xs text-slate-400 mt-2 space-y-0.5">
              <div>ABV: <span class="text-slate-200 font-mono-data">{{ state.product.abvPercent }}%</span></div>
              <div>Active Recipe: <span class="text-amber-300 font-mono-data">{{ state.product.activeRecipeVersion }}</span></div>
              <div>Botanicals: <span class="text-slate-200 font-mono-data">{{ state.botanicals.length }} items</span></div>
            </div>
          </div>

          <!-- Node 2: Distillation & Factory -->
          <div (click)="navigateTo.emit('distillery')" class="bg-slate-900/80 border border-slate-700 hover:border-sky-500 rounded-xl p-4 cursor-pointer transition-all hover:scale-[1.02] group">
            <div class="text-xs font-mono-data text-sky-400 mb-1 flex items-center justify-between">
              <span>02. STILLHOUSE & MES</span>
              <span class="group-hover:translate-x-1 transition-transform">→</span>
            </div>
            <div class="font-bold text-slate-100 text-sm">1,000L Caledonian Still</div>
            <div class="text-xs text-slate-400 mt-2 space-y-0.5">
              <div>Yield / Batch: <span class="text-slate-200 font-mono-data">~1,250 bottles</span></div>
              <div>Active Batches: <span class="text-sky-300 font-mono-data">{{ state.batches.length }}</span></div>
              <div>Utilisation: <span class="text-slate-200 font-mono-data">{{ state.financials.capacityUtilisationPercent }}%</span></div>
            </div>
          </div>

          <!-- Node 3: Packaging & Stock -->
          <div (click)="navigateTo.emit('packaging')" class="bg-slate-900/80 border border-slate-700 hover:border-emerald-500 rounded-xl p-4 cursor-pointer transition-all hover:scale-[1.02] group">
            <div class="text-xs font-mono-data text-emerald-400 mb-1 flex items-center justify-between">
              <span>03. PACKAGING & STOCK</span>
              <span class="group-hover:translate-x-1 transition-transform">→</span>
            </div>
            <div class="font-bold text-slate-100 text-sm">Bespoke 700ml Glass</div>
            <div class="text-xs text-slate-400 mt-2 space-y-0.5">
              <div>Bottle Cost: <span class="text-slate-200 font-mono-data">£{{ state.packaging.bottleUnitCostGbp }}</span></div>
              <div>In Warehouse: <span class="text-emerald-300 font-mono-data">{{ state.financials.currentInventoryBottles }} btl</span></div>
              <div>Recyclability: <span class="text-slate-200 font-mono-data">{{ state.packaging.recyclabilityPercent }}%</span></div>
            </div>
          </div>

          <!-- Node 4: Orders & Pricing -->
          <div (click)="navigateTo.emit('costing')" class="bg-slate-900/80 border border-slate-700 hover:border-purple-500 rounded-xl p-4 cursor-pointer transition-all hover:scale-[1.02] group">
            <div class="text-xs font-mono-data text-purple-400 mb-1 flex items-center justify-between">
              <span>04. COGS & MARGIN</span>
              <span class="group-hover:translate-x-1 transition-transform">→</span>
            </div>
            <div class="font-bold text-slate-100 text-sm">Unit Cost £{{ state.financials.costPerBottleGbp }}</div>
            <div class="text-xs text-slate-400 mt-2 space-y-0.5">
              <div>Wholesale: <span class="text-slate-200 font-mono-data">£{{ state.product.targetWholesalePriceGbp }}</span></div>
              <div>Retail RRP: <span class="text-slate-200 font-mono-data">£{{ state.product.targetRetailPriceGbp }}</span></div>
              <div>Gross Margin: <span class="text-purple-300 font-mono-data">{{ state.financials.grossMarginPercent }}%</span></div>
            </div>
          </div>

          <!-- Node 5: Financial Valuation -->
          <div (click)="navigateTo.emit('costing')" class="bg-slate-900/80 border border-amber-500/40 hover:border-amber-400 rounded-xl p-4 cursor-pointer transition-all hover:scale-[1.02] group">
            <div class="text-xs font-mono-data text-amber-300 mb-1 flex items-center justify-between">
              <span>05. CASH & VALUE</span>
              <span class="group-hover:translate-x-1 transition-transform">✓</span>
            </div>
            <div class="font-bold text-slate-100 text-sm">£{{ state.financials.companyValuationGbp | number:'1.0-0' }}</div>
            <div class="text-xs text-slate-400 mt-2 space-y-0.5">
              <div>Runway: <span class="text-amber-300 font-mono-data">{{ state.financials.runwayMonths }} mo</span></div>
              <div>Monthly Rev: <span class="text-slate-200 font-mono-data">£{{ state.financials.monthlyRevenueGbp | number }}</span></div>
              <div>EBITDA: <span class="text-emerald-400 font-mono-data">£{{ state.financials.ebitdaGbp | number }}</span></div>
            </div>
          </div>

        </div>
      </div>

      <!-- TWO-COLUMN SECTION: FLAGSHIP HERO + LIVE EVENT FEED -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        <!-- FLAGSHIP PRODUCT HERO CARD (7 cols) -->
        <div class="lg:col-span-7 bg-[#121824] border border-slate-800 rounded-2xl p-6 space-y-6 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between mb-4">
              <span class="text-xs font-mono-data text-amber-400 uppercase tracking-widest">FLAGSHIP BRAND PRODUCT</span>
              <button (click)="navigateTo.emit('products')" class="text-xs text-slate-400 hover:text-amber-300 underline">View Full Product Studio</button>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-12 gap-6 items-center">
              <div class="sm:col-span-5 relative group">
                <img
                  [src]="state.product.imageUrl || '/assets/images/north_atlantic_bottle_1790507856346.jpg'"
                  alt="North Atlantic Dry Gin"
                  class="rounded-xl object-cover w-full h-64 border border-slate-700/80 shadow-xl group-hover:scale-[1.01] transition-transform"
                />
                <div class="absolute bottom-2 left-2 right-2 bg-slate-900/90 backdrop-blur px-2.5 py-1 rounded text-[10px] font-mono-data text-slate-300 border border-slate-700 flex justify-between">
                  <span>{{ state.product.bottleVolumeMl }}ml</span>
                  <span>{{ state.product.abvPercent }}% ABV</span>
                </div>
              </div>

              <div class="sm:col-span-7 space-y-3">
                <h3 class="font-serif-brand text-2xl font-bold text-white tracking-wide">
                  {{ state.product.name }}
                </h3>
                <div class="text-xs text-amber-400/90 font-medium font-mono-data">
                  {{ state.product.commercialCategory }}
                </div>
                <p class="text-xs text-slate-300 leading-relaxed italic">
                  "{{ state.product.botanicalPhilosophy }}"
                </p>

                <div class="pt-2 border-t border-slate-800 grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <span class="text-slate-400 block text-[10px] uppercase font-mono-data">Target Retail</span>
                    <span class="font-mono-data font-bold text-slate-100 text-sm">£{{ state.product.targetRetailPriceGbp }}</span>
                  </div>
                  <div>
                    <span class="text-slate-400 block text-[10px] uppercase font-mono-data">Wholesale</span>
                    <span class="font-mono-data font-bold text-slate-100 text-sm">£{{ state.product.targetWholesalePriceGbp }}</span>
                  </div>
                  <div>
                    <span class="text-slate-400 block text-[10px] uppercase font-mono-data">Batch Cost / Btl</span>
                    <span class="font-mono-data font-bold text-emerald-400 text-sm">£{{ state.financials.costPerBottleGbp }}</span>
                  </div>
                  <div>
                    <span class="text-slate-400 block text-[10px] uppercase font-mono-data">Gross Margin</span>
                    <span class="font-mono-data font-bold text-amber-400 text-sm">{{ state.financials.grossMarginPercent }}%</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400 font-mono-data">
            <span>LEGAL: {{ state.product.legalClassification }}</span>
            <button (click)="navigateTo.emit('recipes')" class="text-amber-400 hover:underline">Edit Recipe ({{ state.product.activeRecipeVersion }}) →</button>
          </div>
        </div>

        <!-- REAL-TIME DIGITAL TWIN EVENT FEED (5 cols) -->
        <div class="lg:col-span-5 bg-[#121824] border border-slate-800 rounded-2xl p-6 space-y-4 flex flex-col">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2">
              <span class="w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>
              <h3 class="font-serif-brand font-bold text-white text-base">Causal Event Stream</h3>
            </div>
            <span class="text-[10px] font-mono-data text-slate-400">STATE DEPENDENCY LOG</span>
          </div>

          <div class="space-y-3 overflow-y-auto max-h-[300px] pr-1 no-scrollbar">
            <div
              *ngFor="let log of eventLogs"
              class="bg-slate-900/60 border border-slate-800 rounded-lg p-3 space-y-1 text-xs"
            >
              <div class="flex items-center justify-between font-mono-data text-[10px] text-slate-400">
                <span class="text-amber-400 font-bold uppercase">{{ log.eventType }}</span>
                <span>{{ log.timestamp }}</span>
              </div>
              <p class="text-slate-200 font-medium">{{ log.description }}</p>
              <p class="text-[11px] text-emerald-400 font-mono-data pt-0.5">{{ log.impactSummary }}</p>
            </div>
          </div>
        </div>

      </div>

    </div>
  `,
})
export class OverviewComponent {
  @Input() state!: CompanyState;
  @Input() eventLogs: EventLogItem[] = [];

  @Output() navigateTo = new EventEmitter<string>();
  @Output() openFounderWizard = new EventEmitter<void>();
  @Output() openScaleUpWizard = new EventEmitter<void>();
}
