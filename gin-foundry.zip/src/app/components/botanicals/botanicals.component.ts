import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Botanical, BotanicalLot, CompanyState } from '../../models/digital-twin.model';

@Component({
  selector: 'app-botanicals',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="space-y-8 pb-12">
      
      <!-- HEADER -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div class="text-xs font-mono-data text-amber-400 mb-1">MODULE 04 & 05 // BOTANICAL LIBRARY & SUPPLY CHAIN DIGITAL TWIN</div>
          <h1 class="font-serif-brand text-2xl sm:text-3xl font-bold text-white">Botanical Sourcing & Inventory Pipeline</h1>
          <p class="text-xs text-slate-400 mt-1">
            Every botanical is a supply-chain object tracked from harvest field to lot reservation and copper still extraction.
          </p>
        </div>

        <button
          (click)="showAddModal = true"
          class="px-4 py-2 text-xs font-semibold rounded-lg bg-amber-600 hover:bg-amber-500 text-white shadow-md transition-all flex items-center gap-1.5"
        >
          <span class="material-icons text-sm">add</span>
          <span>ADD CUSTOM BOTANICAL</span>
        </button>
      </div>

      <!-- BOTANICAL FLATLAY IMAGE & SUPPLY CHAIN SUMMARY -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
        <div class="lg:col-span-5 relative group">
          <img
            src="/src/assets/images/botanicals_collection_1790507876700.jpg"
            alt="Botanicals Collection"
            class="rounded-xl w-full h-56 object-cover border border-slate-800 shadow-xl"
          />
          <div class="absolute bottom-2 left-2 bg-slate-950/80 backdrop-blur px-3 py-1 rounded text-xs font-mono-data text-amber-300 border border-slate-700">
            Caledonian Foraged & Imported Botanicals
          </div>
        </div>

        <div class="lg:col-span-7 grid grid-cols-2 sm:grid-cols-3 gap-4">
          <div class="bg-[#121824] border border-slate-800 rounded-xl p-4 space-y-1">
            <div class="text-[11px] font-mono-data text-slate-400 uppercase">Active Botanicals</div>
            <div class="text-2xl font-bold font-mono-data text-white">{{ state.botanicals.length }} items</div>
            <div class="text-[11px] text-amber-400 font-mono-data">6 Core Recipe Ingredients</div>
          </div>

          <div class="bg-[#121824] border border-slate-800 rounded-xl p-4 space-y-1">
            <div class="text-[11px] font-mono-data text-slate-400 uppercase">Juniper Stock</div>
            <div class="text-2xl font-bold font-mono-data text-emerald-400">148 kg</div>
            <div class="text-[11px] text-slate-400 font-mono-data">Supplier Reliability: 98%</div>
          </div>

          <div class="bg-[#121824] border border-slate-800 rounded-xl p-4 space-y-1">
            <div class="text-[11px] font-mono-data text-slate-400 uppercase">Active Inventory Lots</div>
            <div class="text-2xl font-bold font-mono-data text-sky-400">{{ state.botanicalLots.length }} Lots</div>
            <div class="text-[11px] text-emerald-400 font-mono-data">100% Quality Inspected</div>
          </div>
        </div>
      </div>

      <!-- BOTANICAL LIBRARY GRID -->
      <div class="space-y-4">
        <h3 class="font-serif-brand text-xl font-bold text-white border-b border-slate-800 pb-2">
          Botanical Ingredient Database
        </h3>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div
            *ngFor="let b of state.botanicals"
            class="bg-[#121824] border border-slate-800 hover:border-amber-500/50 rounded-2xl p-5 space-y-4 transition-all"
          >
            <div class="flex items-start justify-between">
              <div>
                <span class="text-[10px] font-mono-data text-amber-400 uppercase tracking-widest">{{ b.category }}</span>
                <h4 class="font-serif-brand font-bold text-lg text-white">{{ b.commonName }}</h4>
                <div class="text-xs text-slate-400 italic font-serif">{{ b.latinName }}</div>
              </div>
              <span class="text-sm font-bold font-mono-data text-emerald-400">£{{ b.pricePerKg }}/kg</span>
            </div>

            <div class="text-xs space-y-1.5 text-slate-300">
              <div class="flex justify-between border-b border-slate-800/80 pb-1">
                <span class="text-slate-400">Origin Region:</span>
                <span class="font-medium text-slate-200">{{ b.origin }}</span>
              </div>
              <div class="flex justify-between border-b border-slate-800/80 pb-1">
                <span class="text-slate-400">Supplier:</span>
                <span class="font-medium text-amber-300/90">{{ b.supplier }}</span>
              </div>
              <div class="flex justify-between border-b border-slate-800/80 pb-1">
                <span class="text-slate-400">Extraction Index:</span>
                <span class="font-mono-data text-slate-200">{{ b.extractionIndex }}x</span>
              </div>
              <div class="flex justify-between border-b border-slate-800/80 pb-1">
                <span class="text-slate-400">Intensity Score:</span>
                <span class="font-mono-data text-amber-400 font-bold">{{ b.intensityScore }} / 10</span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-400">Lead Time:</span>
                <span class="font-mono-data text-slate-200">{{ b.leadTimeDays }} Days</span>
              </div>
            </div>

            <div class="space-y-1 pt-2">
              <span class="text-[10px] text-slate-400 uppercase font-mono-data block">Aroma Compounds</span>
              <div class="flex flex-wrap gap-1 text-[11px] font-mono-data text-slate-300">
                <span *ngFor="let compound of b.aromaCompounds" class="bg-slate-900 border border-slate-800 px-2 py-0.5 rounded">
                  #{{ compound }}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- BOTANICAL INVENTORY LOTS PIPELINE -->
      <div class="bg-[#121824] border border-slate-800 rounded-2xl p-6 space-y-4">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 class="font-serif-brand text-lg font-bold text-white">Botanical Inventory Lot Digital Twin</h3>
            <p class="text-xs text-slate-400">Real-time lot reservation & batch traceability mapping.</p>
          </div>
          <span class="text-xs font-mono-data text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded">AUDITED INVENTORY</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs font-mono-data">
            <thead>
              <tr class="text-slate-400 border-b border-slate-800 uppercase text-[10px]">
                <th class="py-2.5 px-3">Lot Number</th>
                <th class="py-2.5 px-3">Botanical</th>
                <th class="py-2.5 px-3">Supplier</th>
                <th class="py-2.5 px-3">Total Stock</th>
                <th class="py-2.5 px-3">Reserved</th>
                <th class="py-2.5 px-3">Available</th>
                <th class="py-2.5 px-3">Cost / kg</th>
                <th class="py-2.5 px-3">Expiry Date</th>
                <th class="py-2.5 px-3">QC Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 text-slate-200">
              <tr *ngFor="let lot of state.botanicalLots" class="hover:bg-slate-900/50">
                <td class="py-3 px-3 font-bold text-amber-400">{{ lot.lotNumber }}</td>
                <td class="py-3 px-3 font-sans font-medium text-white">{{ lot.botanicalName }}</td>
                <td class="py-3 px-3 text-slate-300">{{ lot.supplier }}</td>
                <td class="py-3 px-3 font-bold text-white">{{ lot.quantityKg }} kg</td>
                <td class="py-3 px-3 text-amber-300">{{ lot.reservedKg }} kg</td>
                <td class="py-3 px-3 text-emerald-400 font-bold">{{ lot.availableKg }} kg</td>
                <td class="py-3 px-3">£{{ lot.costPerKg }}</td>
                <td class="py-3 px-3 text-slate-400">{{ lot.expiryDate }}</td>
                <td class="py-3 px-3">
                  <span class="px-2 py-0.5 text-[10px] rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    {{ lot.qualityStatus }}
                  </span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- MODAL: ADD CUSTOM BOTANICAL -->
      <div *ngIf="showAddModal" class="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
        <div class="bg-[#121824] border border-slate-700 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 class="font-serif-brand font-bold text-white text-lg">Add Custom Botanical to Library</h3>
            <button (click)="showAddModal = false" class="text-slate-400 hover:text-white">✕</button>
          </div>

          <div class="grid grid-cols-2 gap-3 text-xs">
            <div>
              <label class="text-slate-300 block mb-1">Common Name</label>
              <input [(ngModel)]="newBotanical.commonName" type="text" class="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white outline-none" placeholder="e.g. Scottish Pine Needles" />
            </div>
            <div>
              <label class="text-slate-300 block mb-1">Latin Name</label>
              <input [(ngModel)]="newBotanical.latinName" type="text" class="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white outline-none" placeholder="e.g. Pinus sylvestris" />
            </div>
            <div>
              <label class="text-slate-300 block mb-1">Origin</label>
              <input [(ngModel)]="newBotanical.origin" type="text" class="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white outline-none" placeholder="e.g. Highland Forest" />
            </div>
            <div>
              <label class="text-slate-300 block mb-1">Price / kg (£)</label>
              <input [(ngModel)]="newBotanical.pricePerKg" type="number" class="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white outline-none" />
            </div>
          </div>

          <div class="flex justify-end gap-2 pt-3 border-t border-slate-800">
            <button (click)="showAddModal = false" class="px-3 py-1.5 text-xs text-slate-400 hover:text-white">Cancel</button>
            <button (click)="submitCustomBotanical()" class="px-4 py-1.5 text-xs font-semibold bg-amber-600 hover:bg-amber-500 text-white rounded-lg">Save Botanical</button>
          </div>
        </div>
      </div>

    </div>
  `,
})
export class BotanicalsComponent {
  @Input() state!: CompanyState;
  @Output() addBotanical = new EventEmitter<Botanical>();

  showAddModal = false;

  newBotanical: Botanical = {
    id: `bot-custom-${Date.now()}`,
    commonName: 'Scottish Pine Needles',
    latinName: 'Pinus sylvestris',
    origin: 'Cairngorms Forest',
    supplier: 'Highland Wild Harvest',
    country: 'United Kingdom',
    harvestPeriod: 'Spring',
    organicStatus: true,
    pricePerKg: 28.0,
    moisturePercent: 11.0,
    typicalFlavourNotes: ['Resinous', 'Pine', 'Fresh', 'Woody'],
    aromaCompounds: ['alpha-pinene', 'limonene'],
    intensityScore: 8,
    extractionIndex: 1.1,
    recommendedDosageRange: { minGramsPerLitre: 2, maxGramsPerLitre: 8 },
    shelfLifeDays: 180,
    leadTimeDays: 7,
    supplierReliabilityPercent: 95,
    carbonFootprintKgPerKg: 0.3,
    category: 'herbal',
  };

  submitCustomBotanical() {
    this.newBotanical.id = `bot-custom-${Date.now()}`;
    this.addBotanical.emit({ ...this.newBotanical });
    this.showAddModal = false;
  }
}
