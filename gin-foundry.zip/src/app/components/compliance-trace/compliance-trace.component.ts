import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CompanyState, CustomerOrder, ProductionBatch } from '../../models/digital-twin.model';

@Component({
  selector: 'app-compliance-trace',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="space-y-8 pb-12">
      
      <!-- HEADER -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div class="text-xs font-mono-data text-amber-400 mb-1">MODULE 26, 27 & 28 // REGULATORY COMPLIANCE & LOT TRACEABILITY</div>
          <h1 class="font-serif-brand text-2xl sm:text-3xl font-bold text-white">Traceability & Recall Simulator</h1>
          <p class="text-xs text-slate-400 mt-1">
            Complete lot genealogy linking individual customer bottles back to raw botanical field harvest lots and distillery runs.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <span class="text-xs font-mono-data text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-3 py-1.5 rounded">
            HMRC SPIRIT RECORDS: AUDITED & COMPLIANT
          </span>
        </div>
      </div>

      <!-- TRACE & RECALL SIMULATOR ENGINE -->
      <div class="bg-[#121824] border border-amber-500/40 rounded-2xl p-6 space-y-6 shadow-xl">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div>
            <h3 class="font-serif-brand text-lg font-bold text-white flex items-center gap-2">
              <span class="material-icons text-amber-400">warning_amber</span>
              <span>Trace & Recall Simulator</span>
            </h3>
            <p class="text-xs text-slate-400">Select any raw botanical lot to instantly determine all affected batches, bottles, and customer shipments.</p>
          </div>

          <!-- Lot Selector / Input -->
          <div class="flex items-center gap-2">
            <select
              [(ngModel)]="searchLot"
              (change)="runTrace()"
              class="bg-slate-900 border border-amber-500/60 text-amber-300 font-mono-data text-xs rounded-lg px-3 py-2 outline-none"
            >
              <option value="">-- Select Botanical Lot to Trace --</option>
              <option *ngFor="let lot of state.botanicalLots" [value]="lot.lotNumber">
                {{ lot.lotNumber }} — {{ lot.botanicalName }} ({{ lot.supplier }})
              </option>
            </select>

            <button
              (click)="runTrace()"
              class="px-3 py-2 text-xs font-semibold bg-amber-600 hover:bg-amber-500 text-white rounded-lg shadow"
            >
              RUN SIMULATION
            </button>
          </div>
        </div>

        <!-- RECALL IMPACT RESULTS MATRIX -->
        <div *ngIf="traceResult" class="space-y-6">
          <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-1">
              <div class="text-[11px] font-mono-data text-slate-400 uppercase">Batches Affected</div>
              <div class="text-2xl font-bold font-mono-data text-amber-400">{{ traceResult.batches.length }} Batches</div>
              <div class="text-[11px] text-slate-400 font-mono-data">
                <span *ngFor="let b of traceResult.batches">{{ b.batchNumber }} </span>
              </div>
            </div>

            <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-1">
              <div class="text-[11px] font-mono-data text-slate-400 uppercase">Affected Shipments</div>
              <div class="text-2xl font-bold font-mono-data text-rose-400">{{ traceResult.orders.length }} Customer Orders</div>
              <div class="text-[11px] text-slate-400 font-mono-data">Dispatched to trade accounts</div>
            </div>

            <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-1">
              <div class="text-[11px] font-mono-data text-slate-400 uppercase">Total Bottles in Market</div>
              <div class="text-2xl font-bold font-mono-data text-white">{{ traceResult.totalBottles }} Bottles</div>
              <div class="text-[11px] text-emerald-400 font-mono-data">Recall Protocol Actionable</div>
            </div>
          </div>

          <!-- Impacted Orders Table -->
          <div *ngIf="traceResult.orders.length > 0" class="space-y-2">
            <div class="text-xs font-mono-data text-slate-300 font-bold uppercase">Impacted Customer Orders & Dispatch Log:</div>
            <div class="overflow-x-auto">
              <table class="w-full text-left text-xs font-mono-data">
                <thead>
                  <tr class="text-slate-400 border-b border-slate-800 uppercase text-[10px]">
                    <th class="py-2 px-3">Order #</th>
                    <th class="py-2 px-3">Customer</th>
                    <th class="py-2 px-3">Customer Type</th>
                    <th class="py-2 px-3">Quantity</th>
                    <th class="py-2 px-3">Order Date</th>
                    <th class="py-2 px-3">Allocated Batch</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-slate-800 text-slate-200">
                  <tr *ngFor="let o of traceResult.orders">
                    <td class="py-2.5 px-3 text-amber-400 font-bold">{{ o.orderNumber }}</td>
                    <td class="py-2.5 px-3 font-sans font-medium text-white">{{ o.customerName }}</td>
                    <td class="py-2.5 px-3 text-slate-400">{{ o.customerType }}</td>
                    <td class="py-2.5 px-3 font-bold text-white">{{ o.bottlesCount }} btl ({{ o.quantityCases }} cases)</td>
                    <td class="py-2.5 px-3 text-slate-400">{{ o.orderDate }}</td>
                    <td class="py-2.5 px-3 text-emerald-400 font-bold">{{ o.allocatedBatchId }}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <!-- FULL LOT GENEALOGY TREE -->
      <div class="bg-[#121824] border border-slate-800 rounded-2xl p-6 space-y-4">
        <h3 class="font-serif-brand text-lg font-bold text-white border-b border-slate-800 pb-3">
          Complete Lot Genealogy Map
        </h3>

        <div class="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3 font-mono-data text-xs">
          <div class="flex items-center gap-2 text-amber-400 font-bold">
            <span>[BOTTLE]</span>
            <span class="text-slate-200">NORTH ATLANTIC DRY GIN 700ML (43% ABV)</span>
          </div>
          <div class="pl-4 border-l-2 border-amber-500/50 space-y-2">
            <div class="text-slate-300">↓ BATCH: <span class="text-white font-bold">2026-0048 (1,000L Distillation Run)</span></div>
            <div class="pl-4 border-l-2 border-sky-500/50 space-y-1">
              <div class="text-slate-400">↓ RECIPE: <span class="text-amber-300 font-bold">v1.0 Commercial Production Standard</span></div>
              <div class="pl-4 border-l-2 border-emerald-500/50 space-y-1 text-slate-300">
                <div>• BOTANICAL LOT: <span class="text-emerald-400">LOT-J-8821</span> (Juniper Berries — Caledonian Botanicals)</div>
                <div>• BOTANICAL LOT: <span class="text-emerald-400">LOT-H-4412</span> (Wild Heather — Highland Foragers)</div>
                <div>• BOTANICAL LOT: <span class="text-emerald-400">LOT-S-9121</span> (Sea Buckthorn — North Sea Organics)</div>
                <div>• BOTANICAL LOT: <span class="text-emerald-400">LOT-C-2218</span> (Coriander Seed — English Spice)</div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  `,
})
export class ComplianceTraceComponent {
  @Input() state!: CompanyState;
  @Output() traceLot = new EventEmitter<string>();

  searchLot = 'LOT-J-8821';
  traceResult?: { batches: ProductionBatch[]; orders: CustomerOrder[]; totalBottles: number };

  ngOnInit() {
    this.runTrace();
  }

  runTrace() {
    if (!this.searchLot) return;
    const lot = this.searchLot;
    const affectedBatches = this.state.batches.filter((b) =>
      b.botanicalLotNumbers.some((l) => l.lotNumber.toUpperCase() === lot.toUpperCase())
    );
    const affectedBatchIds = affectedBatches.map((b) => b.id);
    const affectedOrders = this.state.orders.filter((o) => o.allocatedBatchId && affectedBatchIds.includes(o.allocatedBatchId));
    const totalBottles = affectedOrders.reduce((sum, o) => sum + o.bottlesCount, 0);

    this.traceResult = { batches: affectedBatches, orders: affectedOrders, totalBottles };
  }
}
