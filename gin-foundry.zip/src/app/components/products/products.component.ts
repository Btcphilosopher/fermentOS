import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CompanyState, ProductSpecification } from '../../models/digital-twin.model';

@Component({
  selector: 'app-products',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="space-y-8 pb-12">
      
      <!-- HEADER -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div class="text-xs font-mono-data text-amber-400 mb-1">MODULE 02 // GIN PRODUCT CREATION STUDIO</div>
          <h1 class="font-serif-brand text-2xl sm:text-3xl font-bold text-white">Product Development Studio</h1>
          <p class="text-xs text-slate-400 mt-1">
            Separate commercial positioning from strict legal regulatory classification. Updates automatically propagate to bottle geometry and COGS.
          </p>
        </div>

        <button
          (click)="saveProductChanges()"
          class="px-4 py-2 text-xs font-semibold rounded-lg bg-amber-600 hover:bg-amber-500 text-white shadow-md transition-all self-start sm:self-auto flex items-center gap-1.5"
        >
          <span class="material-icons text-sm">save</span>
          <span>PROPAGATE PRODUCT SPEC</span>
        </button>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        <!-- BOTTLE PREVIEW & LIVE MARGIN CARDS (5 cols) -->
        <div class="lg:col-span-5 space-y-6">
          <div class="bg-[#121824] border border-slate-800 rounded-2xl p-6 space-y-4">
            <h3 class="font-serif-brand text-lg font-bold text-white flex items-center justify-between">
              <span>Bespoke Product Rendering</span>
              <span class="text-xs font-mono-data text-amber-400">700 ML · {{ tempProduct.abvPercent }}% ABV</span>
            </h3>

            <div class="relative group">
              <img
                [src]="tempProduct.imageUrl || '/assets/images/north_atlantic_bottle_1790507856346.jpg'"
                alt="Product Bottle Render"
                class="rounded-xl w-full h-80 object-cover border border-slate-700 shadow-2xl"
              />
              <div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent rounded-xl flex items-end p-4">
                <div>
                  <div class="font-serif-brand font-bold text-xl text-white">{{ tempProduct.name }}</div>
                  <div class="text-xs font-mono-data text-amber-300">{{ tempProduct.commercialCategory }}</div>
                </div>
              </div>
            </div>

            <!-- Unit Economics Live Matrix -->
            <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-3">
              <div class="text-xs font-mono-data text-slate-400 uppercase tracking-wider">Unit Commercial Economics</div>
              
              <div class="grid grid-cols-2 gap-4 text-xs">
                <div>
                  <span class="text-slate-400 block">Current Batch Cost / Btl</span>
                  <span class="text-base font-bold font-mono-data text-emerald-400">£{{ state.financials.costPerBottleGbp | number:'1.2-2' }}</span>
                </div>
                <div>
                  <span class="text-slate-400 block">Target Gross Margin</span>
                  <span class="text-base font-bold font-mono-data text-amber-400">{{ calculatedGrossMargin | number:'1.1-1' }}%</span>
                </div>
                <div>
                  <span class="text-slate-400 block">Wholesale Profit / Btl</span>
                  <span class="text-sm font-bold font-mono-data text-slate-100">£{{ (tempProduct.targetWholesalePriceGbp - state.financials.costPerBottleGbp) | number:'1.2-2' }}</span>
                </div>
                <div>
                  <span class="text-slate-400 block">Contribution Margin</span>
                  <span class="text-sm font-bold font-mono-data text-purple-400">£{{ state.financials.contributionMarginGbp }}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- PRODUCT EDITOR FORM (7 cols) -->
        <div class="lg:col-span-7 bg-[#121824] border border-slate-800 rounded-2xl p-6 space-y-6">
          <h3 class="font-serif-brand text-lg font-bold text-white border-b border-slate-800 pb-3">
            Product Specification & Regulatory Classification
          </h3>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            
            <div class="space-y-1">
              <label class="font-medium text-slate-300">Product Name</label>
              <input
                type="text"
                [(ngModel)]="tempProduct.name"
                class="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 focus:border-amber-500 outline-none"
              />
            </div>

            <div class="space-y-1">
              <label class="font-medium text-slate-300">Brand Name</label>
              <input
                type="text"
                [(ngModel)]="tempProduct.brand"
                class="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 focus:border-amber-500 outline-none"
              />
            </div>

            <div class="space-y-1">
              <label class="font-medium text-amber-400">Commercial Product Category</label>
              <input
                type="text"
                [(ngModel)]="tempProduct.commercialCategory"
                placeholder="e.g. Scottish Highland Dry Gin"
                class="w-full bg-slate-900 border border-amber-500/40 rounded-lg px-3 py-2 text-slate-100 focus:border-amber-500 outline-none"
              />
              <span class="text-[10px] text-slate-500">Market branding & commercial category</span>
            </div>

            <div class="space-y-1">
              <label class="font-medium text-sky-400">Legal / Regulatory Classification</label>
              <input
                type="text"
                [(ngModel)]="tempProduct.legalClassification"
                placeholder="e.g. Distilled Gin (UK HMRC Reg)"
                class="w-full bg-slate-900 border border-sky-500/40 rounded-lg px-3 py-2 text-slate-100 focus:border-sky-500 outline-none"
              />
              <span class="text-[10px] text-slate-500">Official HMRC & EU spirit regulation tag</span>
            </div>

            <!-- ABV Slider -->
            <div class="space-y-1">
              <div class="flex justify-between text-slate-300">
                <label class="font-medium">Alcohol By Volume (ABV)</label>
                <span class="font-mono-data text-amber-400 font-bold">{{ tempProduct.abvPercent }}% ABV</span>
              </div>
              <input
                type="range"
                min="37.5"
                max="57.0"
                step="0.5"
                [(ngModel)]="tempProduct.abvPercent"
                class="w-full accent-amber-500 bg-slate-800"
              />
              <div class="flex justify-between text-[10px] font-mono-data text-slate-500">
                <span>37.5% (Legal Min)</span>
                <span>43.0% (Standard)</span>
                <span>57.0% (Navy Strength)</span>
              </div>
            </div>

            <!-- Bottle Volume -->
            <div class="space-y-1">
              <label class="font-medium text-slate-300">Bottle Volume (ml)</label>
              <select
                [(ngModel)]="tempProduct.bottleVolumeMl"
                class="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 focus:border-amber-500 outline-none font-mono-data"
              >
                <option [ngValue]="500">500 ml (Boutique / Export)</option>
                <option [ngValue]="700">700 ml (Standard UK/EU)</option>
                <option [ngValue]="750">750 ml (US Market Standard)</option>
              </select>
            </div>

            <!-- Target Retail Price -->
            <div class="space-y-1">
              <div class="flex justify-between text-slate-300">
                <label class="font-medium">Target Retail Price (RRP)</label>
                <span class="font-mono-data text-emerald-400 font-bold">£{{ tempProduct.targetRetailPriceGbp | number:'1.2-2' }}</span>
              </div>
              <input
                type="range"
                min="20"
                max="85"
                step="1"
                [(ngModel)]="tempProduct.targetRetailPriceGbp"
                (ngModelChange)="onRetailPriceChange()"
                class="w-full accent-emerald-500 bg-slate-800"
              />
            </div>

            <!-- Target Wholesale Price -->
            <div class="space-y-1">
              <div class="flex justify-between text-slate-300">
                <label class="font-medium">Target Wholesale Price</label>
                <span class="font-mono-data text-purple-400 font-bold">£{{ tempProduct.targetWholesalePriceGbp | number:'1.2-2' }}</span>
              </div>
              <input
                type="range"
                min="12"
                max="55"
                step="0.5"
                [(ngModel)]="tempProduct.targetWholesalePriceGbp"
                class="w-full accent-purple-500 bg-slate-800"
              />
            </div>

          </div>

          <!-- Botanical Philosophy & Brand Positioning -->
          <div class="space-y-4 pt-4 border-t border-slate-800 text-xs">
            <div class="space-y-1">
              <label class="font-medium text-slate-300">Botanical Philosophy</label>
              <textarea
                [(ngModel)]="tempProduct.botanicalPhilosophy"
                rows="2"
                class="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 text-slate-100 focus:border-amber-500 outline-none"
              ></textarea>
            </div>

            <div class="space-y-1">
              <label class="font-medium text-slate-300">Flavour Profile Direction</label>
              <textarea
                [(ngModel)]="tempProduct.flavourDirection"
                rows="2"
                class="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 text-slate-100 focus:border-amber-500 outline-none"
              ></textarea>
            </div>
          </div>

        </div>

      </div>

    </div>
  `,
})
export class ProductsComponent implements OnInit {
  @Input() state!: CompanyState;
  @Output() updateProduct = new EventEmitter<Partial<ProductSpecification>>();

  tempProduct!: ProductSpecification;

  ngOnInit() {
    this.tempProduct = JSON.parse(JSON.stringify(this.state.product));
  }

  get calculatedGrossMargin(): number {
    const ws = this.tempProduct.targetWholesalePriceGbp;
    const cogs = this.state.financials.costPerBottleGbp;
    if (!ws || ws <= 0) return 0;
    return ((ws - cogs) / ws) * 100;
  }

  onRetailPriceChange() {
    // Standard wholesale ratio ~58% of RRP
    this.tempProduct.targetWholesalePriceGbp = Number((this.tempProduct.targetRetailPriceGbp * 0.58).toFixed(2));
  }

  saveProductChanges() {
    this.updateProduct.emit(this.tempProduct);
  }
}
