import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DigitalTwinService } from './services/digital-twin.service';
import { CompanyState, EventLogItem, TwinScenario } from './models/digital-twin.model';

import { HeaderComponent } from './components/header/header.component';
import { OverviewComponent } from './components/overview/overview.component';
import { ProductsComponent } from './components/products/products.component';
import { RecipesComponent } from './components/recipes/recipes.component';
import { BotanicalsComponent } from './components/botanicals/botanicals.component';
import { LabComponent } from './components/lab/lab.component';
import { DistilleryComponent } from './components/distillery/distillery.component';
import { ProductionMesComponent } from './components/production-mes/production-mes.component';
import { PackagingComponent } from './components/packaging/packaging.component';
import { CostingFinanceComponent } from './components/costing-finance/costing-finance.component';
import { ComplianceTraceComponent } from './components/compliance-trace/compliance-trace.component';
import { ScenarioLabComponent } from './components/scenario-lab/scenario-lab.component';
import { AiAssistantDrawerComponent } from './components/ai-assistant-drawer/ai-assistant-drawer.component';
import { FounderWizardComponent } from './components/founder-wizard/founder-wizard.component';
import { ScaleUpWizardComponent } from './components/scale-up-wizard/scale-up-wizard.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    HeaderComponent,
    OverviewComponent,
    ProductsComponent,
    RecipesComponent,
    BotanicalsComponent,
    LabComponent,
    DistilleryComponent,
    ProductionMesComponent,
    PackagingComponent,
    CostingFinanceComponent,
    ComplianceTraceComponent,
    ScenarioLabComponent,
    AiAssistantDrawerComponent,
    FounderWizardComponent,
    ScaleUpWizardComponent,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit {
  activeTab = 'overview';
  state!: CompanyState;
  scenarios: TwinScenario[] = [];
  eventLogs: EventLogItem[] = [];

  isAiDrawerOpen = false;
  isFounderWizardOpen = false;
  isScaleUpWizardOpen = false;

  constructor(private twinService: DigitalTwinService) {}

  ngOnInit() {
    this.twinService.state$.subscribe((s) => (this.state = s));
    this.twinService.scenarios$.subscribe((sc) => (this.scenarios = sc));
    this.twinService.eventLogs$.subscribe((logs) => (this.eventLogs = logs));
  }

  onTabChange(tabId: string) {
    this.activeTab = tabId;
  }

  onUpdateProduct(updated: any) {
    this.twinService.updateProduct(updated);
  }

  onUpdatePackaging(updated: any) {
    this.twinService.updatePackaging(updated);
  }

  onUpdateDosage(event: { botanicalId: string; gramsPerLitre: number }) {
    this.twinService.updateRecipeBotanicalDosage(event.botanicalId, event.gramsPerLitre);
  }

  onAddBotanical(botanical: any) {
    this.twinService.addBotanical(botanical);
  }

  onScheduleBatch(stillId: string) {
    this.twinService.createNewBatch(stillId);
  }

  onUpdateBatchStatus(event: { batchId: string; status: any }) {
    this.twinService.updateBatchStatus(event.batchId, event.status);
  }

  onSaveScenario(event: { name: string; description: string }) {
    this.twinService.saveScenario(event.name, event.description);
  }

  onLoadScenario(scenarioId: string) {
    this.twinService.loadScenario(scenarioId);
  }

  onBuildGin(event: { ginType: string; location: string; targetVolume: number; retailPrice: number; capitalGbp: number }) {
    this.twinService.generateFounderGinCompany(
      event.ginType,
      event.location,
      event.targetVolume,
      event.retailPrice,
      event.capitalGbp
    );
  }

  onApplyScaleUp() {
    const currentState = this.twinService.getState();
    currentState.financials.annualProductionCapacityBottles = 1000000;
    currentState.financials.companyValuationGbp = 24500000;
    currentState.financials.ebitdaGbp = 12200000;
    this.twinService.updateProduct({});
  }
}
